import { createClient, type SupabaseClient } from "@supabase/supabase-js";

let publicClient: SupabaseClient | null | undefined;

/** Public data is cached for 5 minutes; admin actions can call revalidateTag("public-data"). */
export const PUBLIC_DATA_REVALIDATE_SECONDS = 300;
export const PUBLIC_DATA_TAG = "public-data";

const cachedFetch: typeof fetch = (input, init) =>
  fetch(input, {
    ...init,
    next: { revalidate: PUBLIC_DATA_REVALIDATE_SECONDS, tags: [PUBLIC_DATA_TAG] },
  } as RequestInit);

/**
 * Cookie-less anon client for public pages, so they can be statically cached
 * (ISR) and stay fast. RLS still applies: only published/public rows are visible.
 * Returns null when Supabase is not configured so pages degrade gracefully.
 */
export function createPublicClient(): SupabaseClient | null {
  if (publicClient !== undefined) return publicClient;

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !anonKey) {
    publicClient = null;
    return null;
  }

  publicClient = createClient(url, anonKey, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
    global: { fetch: cachedFetch },
  });
  return publicClient;
}
