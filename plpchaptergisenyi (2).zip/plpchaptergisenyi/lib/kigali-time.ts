/** Rwanda (Africa/Kigali) is UTC+2 all year with no daylight saving time. */
const KIGALI_OFFSET_HOURS = 2;
const LOCAL_PATTERN = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/;

/** Converts a datetime-local value ("2026-12-05T09:00", Kigali time) to a UTC ISO string. */
export function kigaliLocalToIso(local: string | null | undefined): string | null {
  if (!local) return null;
  const match = LOCAL_PATTERN.exec(local.trim());
  if (!match) return null;
  const [, year, month, day, hour, minute] = match.map(Number) as unknown as number[];
  const date = new Date(Date.UTC(year, month - 1, day, hour - KIGALI_OFFSET_HOURS, minute));
  return Number.isNaN(date.getTime()) ? null : date.toISOString();
}

/** Converts a stored UTC timestamp to a datetime-local value in Kigali time. */
export function isoToKigaliLocal(iso: string | null | undefined): string {
  if (!iso) return "";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  const shifted = new Date(date.getTime() + KIGALI_OFFSET_HOURS * 60 * 60 * 1000);
  return shifted.toISOString().slice(0, 16);
}
