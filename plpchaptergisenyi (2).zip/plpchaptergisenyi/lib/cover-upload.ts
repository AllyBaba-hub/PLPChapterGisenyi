import { createClient } from "@/lib/supabase/client";
import { MEDIA_BUCKET, type CoverFolder } from "@/lib/storage";

/** Uploads an already-compressed image from the browser (admin RLS applies) and returns its storage path. */
export async function uploadImage(
  folder: CoverFolder,
  blob: Blob,
  extension: "webp" | "jpg"
): Promise<{ path: string } | { error: string }> {
  try {
    const supabase = createClient();
    const path = `${folder}/${crypto.randomUUID()}.${extension}`;
    const { error } = await supabase.storage.from(MEDIA_BUCKET).upload(path, blob, {
      contentType: blob.type,
      cacheControl: "31536000",
      upsert: false,
    });
    if (error) return { error: "We couldn't upload the image. Please try again." };
    return { path };
  } catch {
    return { error: "We couldn't upload the image. Check your connection and try again." };
  }
}

export async function discardUpload(path: string): Promise<void> {
  try {
    await createClient().storage.from(MEDIA_BUCKET).remove([path]);
  } catch {
    // Best effort: an orphaned image is only a few kilobytes.
  }
}
