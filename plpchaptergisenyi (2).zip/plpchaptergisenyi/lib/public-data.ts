import { cache } from "react";
import { createPublicClient } from "@/lib/supabase/public";
import { isUuid } from "@/lib/utils";

/* ------------------------------------------------------------------ types */

export interface ChapterSettings {
  chapter_name: string;
  parent_organization: string;
  district_location: string;
  contact_email: string;
  contact_phone: string | null;
  about_summary: string;
  applications_open: boolean;
  social_links: Record<string, string>;
}

export interface EventSummary {
  id: string;
  slug: string;
  title: string;
  summary: string;
  location: string;
  start_time: string;
  end_time: string | null;
  cover_image_url: string | null;
  max_capacity: number | null;
  created_at: string;
  updated_at: string;
}

export interface PublicEvent extends EventSummary {
  description: string;
}

export interface NewsSummary {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  cover_image_url: string | null;
  published_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface PublicNewsArticle extends NewsSummary {
  content: string;
}

export interface PublicGalleryItem {
  id: string;
  title: string;
  caption: string | null;
  alt_text: string;
  media_type: "photo" | "video";
  media_url: string;
  created_at: string;
  event: { title: string; slug: string } | null;
}

export interface SitemapEntry {
  slug: string;
  updated_at: string;
}

export const DEFAULT_CHAPTER_SETTINGS: ChapterSettings = {
  chapter_name: "PLP Chapter Gisenyi",
  parent_organization: "Peace and Love Proclaimers (PLP)",
  district_location: "Gisenyi, Rubavu District, Rwanda",
  contact_email: "gisenyi@plpyouth.org",
  contact_phone: null,
  about_summary:
    "PLP Chapter Gisenyi is a decentralized district chapter of Peace and Love Proclaimers (PLP), empowering youth in Rubavu District through peacebuilding, unity, reconciliation, and community service.",
  applications_open: true,
  social_links: {},
};

/* ---------------------------------------------------------------- columns */

export const EVENT_LIST_COLUMNS =
  "id, slug, title, summary, location, start_time, end_time, cover_image_url, max_capacity, created_at, updated_at";
const EVENT_DETAIL_COLUMNS = `${EVENT_LIST_COLUMNS}, description`;
export const NEWS_LIST_COLUMNS =
  "id, slug, title, excerpt, cover_image_url, published_at, created_at, updated_at";
const NEWS_DETAIL_COLUMNS = `${NEWS_LIST_COLUMNS}, content`;

/* ---------------------------------------------------------------- helpers */

function logError(scope: string, message: string): void {
  console.error(`[public-data] ${scope}: ${message}`);
}

function sanitizeSocialLinks(value: unknown): Record<string, string> {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return {};
  const links: Record<string, string> = {};
  for (const [key, raw] of Object.entries(value as Record<string, unknown>)) {
    if (typeof raw !== "string") continue;
    try {
      const url = new URL(raw);
      if (url.protocol === "https:") links[key] = url.toString();
    } catch {
      // Ignore malformed URLs.
    }
  }
  return links;
}

/* --------------------------------------------------------------- settings */

export const getChapterSettings = cache(async (): Promise<ChapterSettings> => {
  const supabase = createPublicClient();
  if (!supabase) return DEFAULT_CHAPTER_SETTINGS;

  const { data, error } = await supabase
    .from("chapter_settings")
    .select(
      "chapter_name, parent_organization, district_location, contact_email, contact_phone, about_summary, applications_open, social_links"
    )
    .eq("id", 1)
    .maybeSingle();

  if (error || !data) {
    if (error) logError("chapter_settings", error.message);
    return DEFAULT_CHAPTER_SETTINGS;
  }

  return {
    ...DEFAULT_CHAPTER_SETTINGS,
    ...data,
    social_links: sanitizeSocialLinks(data.social_links),
  } as ChapterSettings;
});

/* ----------------------------------------------------------------- events */

export const getPublishedEvents = cache(async (limit: number = 60): Promise<EventSummary[]> => {
  const supabase = createPublicClient();
  if (!supabase) return [];

  const { data, error } = await supabase
    .from("events")
    .select(EVENT_LIST_COLUMNS)
    .eq("is_published", true)
    .order("start_time", { ascending: false })
    .limit(limit);

  if (error) {
    logError("events", error.message);
    return [];
  }
  return (data ?? []) as EventSummary[];
});

/** Looks up a published event by slug or UUID. Throws on database errors, returns null when missing. */
export const getEventByKey = cache(async (key: string): Promise<PublicEvent | null> => {
  const supabase = createPublicClient();
  if (!supabase) return null;

  const query = supabase.from("events").select(EVENT_DETAIL_COLUMNS).eq("is_published", true);
  const { data, error } = await (isUuid(key) ? query.eq("id", key) : query.eq("slug", key)).maybeSingle();

  if (error) throw new Error(`Could not load event: ${error.message}`);
  return (data as PublicEvent | null) ?? null;
});

/* ------------------------------------------------------------------- news */

export const getPublishedNews = cache(async (limit: number = 30): Promise<NewsSummary[]> => {
  const supabase = createPublicClient();
  if (!supabase) return [];

  const { data, error } = await supabase
    .from("news_articles")
    .select(NEWS_LIST_COLUMNS)
    .eq("is_published", true)
    .order("published_at", { ascending: false, nullsFirst: false })
    .limit(limit);

  if (error) {
    logError("news_articles", error.message);
    return [];
  }
  return (data ?? []) as NewsSummary[];
});

export const getNewsByKey = cache(async (key: string): Promise<PublicNewsArticle | null> => {
  const supabase = createPublicClient();
  if (!supabase) return null;

  const query = supabase.from("news_articles").select(NEWS_DETAIL_COLUMNS).eq("is_published", true);
  const { data, error } = await (isUuid(key) ? query.eq("id", key) : query.eq("slug", key)).maybeSingle();

  if (error) throw new Error(`Could not load article: ${error.message}`);
  return (data as PublicNewsArticle | null) ?? null;
});

/* ---------------------------------------------------------------- gallery */

interface RawGalleryRow {
  id: string;
  title: string;
  caption: string | null;
  alt_text: string;
  media_type: "photo" | "video";
  media_url: string;
  created_at: string;
  event: { title: string; slug: string } | { title: string; slug: string }[] | null;
}

export const getGalleryItems = cache(async (limit: number = 60): Promise<PublicGalleryItem[]> => {
  const supabase = createPublicClient();
  if (!supabase) return [];

  const { data, error } = await supabase
    .from("gallery_items")
    .select("id, title, caption, alt_text, media_type, media_url, created_at, event:events(title, slug)")
    .order("created_at", { ascending: false })
    .limit(limit);

  if (error) {
    logError("gallery_items", error.message);
    return [];
  }

  return ((data ?? []) as unknown as RawGalleryRow[]).map((row) => ({
    id: row.id,
    title: row.title,
    caption: row.caption,
    alt_text: row.alt_text,
    media_type: row.media_type,
    media_url: row.media_url,
    created_at: row.created_at,
    event: Array.isArray(row.event) ? (row.event[0] ?? null) : row.event,
  }));
});

/* ---------------------------------------------------------------- sitemap */

export const getSitemapEntries = cache(
  async (): Promise<{ events: SitemapEntry[]; news: SitemapEntry[] }> => {
    const supabase = createPublicClient();
    if (!supabase) return { events: [], news: [] };

    const [events, news] = await Promise.all([
      supabase.from("events").select("slug, updated_at").eq("is_published", true).limit(1000),
      supabase.from("news_articles").select("slug, updated_at").eq("is_published", true).limit(1000),
    ]);

    if (events.error) logError("sitemap events", events.error.message);
    if (news.error) logError("sitemap news", news.error.message);

    return {
      events: (events.data ?? []) as SitemapEntry[],
      news: (news.data ?? []) as SitemapEntry[],
    };
  }
);
