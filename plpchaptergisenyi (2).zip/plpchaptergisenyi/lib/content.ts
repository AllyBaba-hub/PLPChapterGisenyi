import type { ChapterSettings } from "@/lib/public-data";

export interface FaqItem {
  question: string;
  answer: string;
}

export const CHAPTER_VALUES = [
  { title: "Peacebuilding", text: "Young people working together to prevent conflict and build lasting peace in their communities." },
  { title: "Unity", text: "Bringing people from different backgrounds together around shared goals." },
  { title: "Reconciliation", text: "Supporting healing, dialogue and understanding between people and communities." },
  { title: "Youth leadership", text: "Giving young people the skills and responsibility to lead change locally." },
] as const;

function whatIs(s: ChapterSettings): FaqItem {
  return {
    question: "What is PLP Chapter Gisenyi?",
    answer: `${s.chapter_name} is a decentralized district chapter of ${s.parent_organization}, a youth-led organization founded in Rwanda in 2007. The chapter serves young people in ${s.district_location} through peacebuilding, unity, reconciliation, youth leadership and community service.`,
  };
}

function howToJoin(s: ChapterSettings): FaqItem {
  return {
    question: "How to join Peace and Love Proclaimers in Gisenyi?",
    answer: `Complete the online application on the Join page with your contact details and your motivation for joining. Chapter leaders review every application. Once it is approved you can sign in to the member portal, register for events and see your digital membership card.${
      s.applications_open ? "" : " Applications are currently closed, so please check back soon or contact the chapter."
    }`,
  };
}

function findEvents(): FaqItem {
  return {
    question: "How can I find out about upcoming events?",
    answer:
      "Upcoming activities are listed on the Events page. Chapter members can register for events in the member portal and receive email alerts when new activities are announced.",
  };
}

export function getHomeFaqs(s: ChapterSettings): FaqItem[] {
  return [whatIs(s), howToJoin(s), findEvents()];
}

export function getAboutFaqs(s: ChapterSettings): FaqItem[] {
  return [
    whatIs(s),
    {
      question: "What is Peace and Love Proclaimers (PLP)?",
      answer: `${s.parent_organization} is a youth-led organization founded in Rwanda in 2007. It focuses on peacebuilding, unity, reconciliation and youth leadership.`,
    },
    {
      question: "Where is PLP Chapter Gisenyi based?",
      answer: `${s.chapter_name} is based in ${s.district_location}. You can reach the chapter by email at ${s.contact_email}${
        s.contact_phone ? ` or by phone on ${s.contact_phone}` : ""
      }.`,
    },
    howToJoin(s),
    findEvents(),
  ];
}
