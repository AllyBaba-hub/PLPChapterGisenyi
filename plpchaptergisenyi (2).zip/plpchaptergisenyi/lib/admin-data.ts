import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";
import { cache } from "react";
import { requireAdmin } from "@/lib/rbac";

/** One admin auth + profile lookup per request, shared by the layout and the page. */
export const getAdmin = cache(async () => requireAdmin());

export const getAdminCounts = cache(async (): Promise<{ pendingApplications: number; unreadMessages: number }> => {
  const { supabase } = await getAdmin();
  const [applications, messages] = await Promise.all([
    supabase.from("membership_applications").select("id", { count: "exact", head: true }).eq("status", "pending"),
    supabase.from("contact_messages").select("id", { count: "exact", head: true }).eq("status", "unread"),
  ]);
  return {
    pendingApplications: applications.count ?? 0,
    unreadMessages: messages.count ?? 0,
  };
});

/** EmailJS requests recorded by this admin suite during the current month (UTC). */
export async function getEmailUsage(supabase: SupabaseClient): Promise<number> {
  const now = new Date();
  const monthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1)).toISOString();

  const { data, error } = await supabase
    .from("audit_logs")
    .select("metadata")
    .eq("action", "EMAIL_NOTIFICATION_SENT")
    .gte("created_at", monthStart)
    .limit(1000);

  if (error) {
    console.error("[admin-data] email usage:", error.message);
    return 0;
  }

  return ((data ?? []) as Array<{ metadata: { requests?: unknown } | null }>).reduce((total, row) => {
    const requests = Number(row.metadata?.requests);
    return total + (Number.isFinite(requests) && requests > 0 ? requests : 0);
  }, 0);
}

export interface AdminSettings {
  chapter_name: string;
  parent_organization: string;
  district_location: string;
  contact_email: string;
  contact_phone: string | null;
  about_summary: string;
  applications_open: boolean;
  auto_email_notifications: boolean;
  social_links: Record<string, string>;
}

export const getAdminSettings = cache(async (): Promise<AdminSettings> => {
  const { supabase } = await getAdmin();
  const { data, error } = await supabase
    .from("chapter_settings")
    .select("chapter_name, parent_organization, district_location, contact_email, contact_phone, about_summary, applications_open, auto_email_notifications, social_links")
    .eq("id", 1)
    .maybeSingle();

  if (error || !data) {
    throw new Error(`Could not load chapter settings: ${error?.message ?? "no settings row"}`);
  }
  const row = data as AdminSettings;
  return {
    ...row,
    social_links:
      typeof row.social_links === "object" && row.social_links !== null && !Array.isArray(row.social_links)
        ? row.social_links
        : {},
  };
});

export interface EmailUsageBreakdown {
  total: number;
  activity: number;
  account: number;
  sends: number;
}

/** EmailJS requests recorded this month (UTC), split by template. */
export async function getEmailUsageBreakdown(supabase: SupabaseClient): Promise<EmailUsageBreakdown> {
  const now = new Date();
  const monthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1)).toISOString();

  const { data, error } = await supabase
    .from("audit_logs")
    .select("metadata")
    .eq("action", "EMAIL_NOTIFICATION_SENT")
    .gte("created_at", monthStart)
    .limit(1000);

  const result: EmailUsageBreakdown = { total: 0, activity: 0, account: 0, sends: 0 };
  if (error) {
    console.error("[admin-data] email usage breakdown:", error.message);
    return result;
  }

  for (const row of (data ?? []) as Array<{ metadata: { requests?: unknown; template?: unknown } | null }>) {
    const requests = Number(row.metadata?.requests);
    if (!Number.isFinite(requests) || requests <= 0) continue;
    result.total += requests;
    result.sends += 1;
    if (row.metadata?.template === "account") result.account += requests;
    else result.activity += requests;
  }
  return result;
}
