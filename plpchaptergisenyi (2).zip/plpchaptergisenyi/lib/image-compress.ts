export const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"] as const;
export const MAX_INPUT_BYTES = 10 * 1024 * 1024;

export class ImageCompressionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ImageCompressionError";
  }
}

export interface CompressOptions {
  /** Longest edge (or square side when `square` is true), in pixels. */
  maxDimension: number;
  maxBytes: number;
  /** Center-crop to a square (profile photos). */
  square?: boolean;
}

export interface CompressedImage {
  blob: Blob;
  width: number;
  height: number;
  extension: "webp" | "jpg";
}

export function validateImageFile(file: File): string | null {
  if (!(ACCEPTED_IMAGE_TYPES as readonly string[]).includes(file.type)) {
    return "Choose a JPEG, PNG or WebP image.";
  }
  if (file.size > MAX_INPUT_BYTES) {
    return "That image is larger than 10 MB. Choose a smaller photo.";
  }
  return null;
}

async function loadBitmap(file: File): Promise<{ source: CanvasImageSource; width: number; height: number; release: () => void }> {
  if (typeof createImageBitmap === "function") {
    try {
      const bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
      return { source: bitmap, width: bitmap.width, height: bitmap.height, release: () => bitmap.close() };
    } catch {
      // Fall through to the <img> decoder.
    }
  }

  const url = URL.createObjectURL(file);
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const element = new Image();
      element.onload = () => resolve(element);
      element.onerror = () => reject(new ImageCompressionError("We couldn't read that image."));
      element.src = url;
    });
    return {
      source: image,
      width: image.naturalWidth,
      height: image.naturalHeight,
      release: () => URL.revokeObjectURL(url),
    };
  } catch (error) {
    URL.revokeObjectURL(url);
    throw error;
  }
}

function canvasToBlob(canvas: HTMLCanvasElement, type: string, quality: number): Promise<Blob | null> {
  return new Promise((resolve) => canvas.toBlob((blob) => resolve(blob), type, quality));
}

/** Resizes and re-encodes an image in the browser so uploads stay small. */
export async function compressImage(file: File, options: CompressOptions): Promise<CompressedImage> {
  const problem = validateImageFile(file);
  if (problem) throw new ImageCompressionError(problem);

  const { source, width, height, release } = await loadBitmap(file);

  try {
    if (!width || !height) throw new ImageCompressionError("We couldn't read that image.");

    const cropSide = Math.min(width, height);
    const sx = options.square ? Math.floor((width - cropSide) / 2) : 0;
    const sy = options.square ? Math.floor((height - cropSide) / 2) : 0;
    const sw = options.square ? cropSide : width;
    const sh = options.square ? cropSide : height;

    let scale = Math.min(1, options.maxDimension / Math.max(sw, sh));
    const qualities = [0.85, 0.75, 0.65, 0.55, 0.45, 0.35];

    for (let attempt = 0; attempt < 5; attempt += 1) {
      const targetWidth = Math.max(1, Math.round(sw * scale));
      const targetHeight = Math.max(1, Math.round(sh * scale));
      const canvas = document.createElement("canvas");
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      const context = canvas.getContext("2d");
      if (!context) throw new ImageCompressionError("Your browser can't process images here.");

      context.fillStyle = "#ffffff";
      context.fillRect(0, 0, targetWidth, targetHeight);
      context.imageSmoothingQuality = "high";
      context.drawImage(source, sx, sy, sw, sh, 0, 0, targetWidth, targetHeight);

      for (const quality of qualities) {
        let blob = await canvasToBlob(canvas, "image/webp", quality);
        // Some browsers silently fall back to PNG when WebP encoding is unsupported.
        if (!blob || blob.type !== "image/webp") blob = await canvasToBlob(canvas, "image/jpeg", quality);
        if (!blob) throw new ImageCompressionError("We couldn't compress that image.");
        if (blob.size <= options.maxBytes) {
          return {
            blob,
            width: targetWidth,
            height: targetHeight,
            extension: blob.type === "image/webp" ? "webp" : "jpg",
          };
        }
      }
      scale *= 0.8;
    }

    throw new ImageCompressionError("That image is too detailed to compress enough. Try a different photo.");
  } finally {
    release();
  }
}
