import "server-only";
import type { SupabaseClient, User } from "@supabase/supabase-js";
import { revalidatePath, revalidateTag } from "next/cache";
import { headers } from "next/headers";
import { checkRateLimit } from "@/lib/api-security";
import { authorizeApi, type Profile } from "@/lib/rbac";
import { PUBLIC_DATA_TAG } from "@/lib/supabase/public";
import { extractClientIp, recordAuditLog, type AuditAction } from "@/services/audit";

export type ActionResult<T = undefined> =
  | { ok: true; message?: string; data?: T }
  | { ok: false; error: string; fieldErrors?: Record<string, string> };

export interface AdminContext {
  supabase: SupabaseClient;
  user: User;
  profile: Profile;
}

export function fail(error: string, fieldErrors?: Record<string, string>): { ok: false; error: string; fieldErrors?: Record<string, string> } {
  return { ok: false, error, ...(fieldErrors ? { fieldErrors } : {}) };
}

/** Authorizes an admin mutation (active admin or super admin) and applies a per-admin rate limit. */
export async function getAdminContext(): Promise<{ ok: true; ctx: AdminContext } | { ok: false; error: string }> {
  const auth = await authorizeApi("admin");
  if (!auth.ok) {
    return {
      ok: false,
      error:
        auth.status === 401
          ? "Your session has expired. Please sign in again."
          : "You don't have permission to do this.",
    };
  }
  if (!checkRateLimit(`admin:mutations:${auth.user.id}`, 120, 60_000)) {
    return { ok: false, error: "Too many requests. Please wait a moment and try again." };
  }
  return { ok: true, ctx: { supabase: auth.supabase, user: auth.user, profile: auth.profile } };
}

export async function adminAudit(
  ctx: AdminContext,
  action: AuditAction,
  entityType: string,
  entityId: string | null,
  metadata: Record<string, unknown> = {}
): Promise<void> {
  const requestHeaders = await headers();
  await recordAuditLog({
    action,
    entityType,
    entityId,
    actorId: ctx.profile.id,
    actorEmail: ctx.profile.email,
    metadata,
    ip: extractClientIp(requestHeaders as unknown as Headers),
  });
}

/** Refreshes cached public pages after content changes (data cache tag + ISR pages). */
export function revalidatePublic(extraPaths: string[] = []): void {
  revalidateTag(PUBLIC_DATA_TAG);
  for (const path of ["/", "/about", "/events", "/news", "/gallery", "/join", "/contact", "/sitemap.xml", ...extraPaths]) {
    revalidatePath(path);
  }
  revalidatePath("/events/[id]", "page");
  revalidatePath("/news/[id]", "page");
}

export function revalidateAdmin(...paths: string[]): void {
  revalidatePath("/admin", "layout");
  for (const path of paths) revalidatePath(path);
}

export function clean(value: unknown, max: number, multiline = false): string {
  if (typeof value !== "string") return "";
  const normalized = value.replace(/\r\n/g, "\n");
  return (multiline ? normalized : normalized.replace(/\s+/g, " ")).trim().slice(0, max);
}

export function isHttpsUrl(value: string): boolean {
  try {
    return new URL(value).protocol === "https:";
  } catch {
    return false;
  }
}

export function slugify(value: string): string {
  const slug = value
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80)
    .replace(/-+$/g, "");
  return slug || "item";
}

/** Returns a slug that is unique in `table`, ignoring the row being edited. */
export async function uniqueSlug(
  supabase: SupabaseClient,
  table: "events" | "news_articles",
  desired: string,
  excludeId?: string
): Promise<string> {
  const base = slugify(desired);
  for (let attempt = 0; attempt < 25; attempt += 1) {
    const candidate = attempt === 0 ? base : `${base}-${attempt + 1}`;
    let query = supabase.from(table).select("id").eq("slug", candidate).limit(1);
    if (excludeId) query = query.neq("id", excludeId);
    const { data, error } = await query;
    if (error) throw new Error(error.message);
    if (!data || data.length === 0) return candidate;
  }
  return `${base}-${Math.random().toString(36).slice(2, 8)}`;
}

/** Shows messages raised by our own database rules (SQLSTATE P0001); hides everything else. */
export function dbMessage(error: { code?: string; message: string }, fallback: string): string {
  return error.code === "P0001" ? error.message : fallback;
}
