import "server-only";
import { cache } from "react";
import { EVENT_LIST_COLUMNS, NEWS_LIST_COLUMNS, type EventSummary, type NewsSummary } from "@/lib/public-data";
import { requireMember } from "@/lib/rbac";

/** One auth + profile lookup per request, shared by the layout and the page. */
export const getMember = cache(async () => requireMember());

/* ------------------------------------------------------------------ events */

export interface EventWithRsvp extends EventSummary {
  registered_count: number;
  is_registered: boolean;
  attended: boolean;
  is_full: boolean;
}

export const getMemberEvents = cache(async (): Promise<EventWithRsvp[]> => {
  const { supabase, user } = await getMember();

  const [events, registrations, counts] = await Promise.all([
    supabase
      .from("events")
      .select(EVENT_LIST_COLUMNS)
      .eq("is_published", true)
      .order("start_time", { ascending: false })
      .limit(100),
    supabase.from("event_registrations").select("event_id, attended").eq("user_id", user.id),
    supabase.rpc("event_registration_counts"),
  ]);

  if (events.error) throw new Error(`Could not load events: ${events.error.message}`);
  if (registrations.error) throw new Error(`Could not load registrations: ${registrations.error.message}`);
  if (counts.error) console.error("[member-data] event_registration_counts:", counts.error.message);

  const countMap = new Map<string, number>();
  for (const row of (counts.data ?? []) as Array<{ event_id: string; registered_count: number }>) {
    countMap.set(row.event_id, Number(row.registered_count));
  }
  const mine = new Map<string, boolean>();
  for (const row of (registrations.data ?? []) as Array<{ event_id: string; attended: boolean }>) {
    mine.set(row.event_id, row.attended);
  }

  return ((events.data ?? []) as EventSummary[]).map((event) => {
    const registered_count = countMap.get(event.id) ?? 0;
    return {
      ...event,
      registered_count,
      is_registered: mine.has(event.id),
      attended: mine.get(event.id) ?? false,
      is_full: event.max_capacity !== null && registered_count >= event.max_capacity,
    };
  });
});

export interface RegistrationRecord {
  id: string;
  attended: boolean;
  registered_at: string;
  event: Pick<
    EventSummary,
    "id" | "slug" | "title" | "location" | "start_time" | "end_time" | "cover_image_url"
  >;
}

interface RawRegistration {
  id: string;
  attended: boolean;
  registered_at: string;
  event: RegistrationRecord["event"] | RegistrationRecord["event"][] | null;
}

export const getMemberRegistrations = cache(async (): Promise<RegistrationRecord[]> => {
  const { supabase, user } = await getMember();

  const { data, error } = await supabase
    .from("event_registrations")
    .select(
      "id, attended, registered_at, event:events(id, slug, title, location, start_time, end_time, cover_image_url)"
    )
    .eq("user_id", user.id)
    .order("registered_at", { ascending: false })
    .limit(200);

  if (error) throw new Error(`Could not load participation history: ${error.message}`);

  const records: RegistrationRecord[] = [];
  for (const row of (data ?? []) as unknown as RawRegistration[]) {
    const event = Array.isArray(row.event) ? row.event[0] : row.event;
    if (event) {
      records.push({ id: row.id, attended: row.attended, registered_at: row.registered_at, event });
    }
  }
  return records;
});

/* ----------------------------------------------------------- announcements */

export type AnnouncementPriority = "normal" | "important" | "urgent";

export interface AnnouncementView {
  id: string;
  title: string;
  body: string;
  priority: AnnouncementPriority;
  created_at: string;
  is_read: boolean;
}

const PRIORITY_RANK: Record<AnnouncementPriority, number> = { urgent: 2, important: 1, normal: 0 };

export const getAnnouncements = cache(async (): Promise<AnnouncementView[]> => {
  const { supabase, user } = await getMember();

  const [announcements, reads] = await Promise.all([
    supabase
      .from("announcements")
      .select("id, title, body, priority, created_at")
      .eq("is_published", true)
      .order("created_at", { ascending: false })
      .limit(100),
    supabase.from("announcement_reads").select("announcement_id").eq("user_id", user.id),
  ]);

  if (announcements.error) throw new Error(`Could not load announcements: ${announcements.error.message}`);
  if (reads.error) throw new Error(`Could not load read state: ${reads.error.message}`);

  const readIds = new Set(
    ((reads.data ?? []) as Array<{ announcement_id: string }>).map((row) => row.announcement_id)
  );

  return ((announcements.data ?? []) as Array<Omit<AnnouncementView, "is_read">>)
    .map((item) => ({ ...item, is_read: readIds.has(item.id) }))
    .sort(
      (a, b) =>
        PRIORITY_RANK[b.priority] - PRIORITY_RANK[a.priority] ||
        b.created_at.localeCompare(a.created_at)
    );
});

export const getUnreadAnnouncementCount = cache(async (): Promise<number> => {
  try {
    return (await getAnnouncements()).filter((item) => !item.is_read).length;
  } catch {
    return 0;
  }
});

/* -------------------------------------------------------------------- news */

export const getRecentNews = cache(async (limit: number = 3): Promise<NewsSummary[]> => {
  const { supabase } = await getMember();
  const { data, error } = await supabase
    .from("news_articles")
    .select(NEWS_LIST_COLUMNS)
    .eq("is_published", true)
    .order("published_at", { ascending: false, nullsFirst: false })
    .limit(limit);

  if (error) {
    console.error("[member-data] news_articles:", error.message);
    return [];
  }
  return (data ?? []) as NewsSummary[];
});
