export type SearchParams = Record<string, string | string[] | undefined>;

export const PAGE_SIZE = 25;

export function pick(params: SearchParams, key: string): string {
  const value = params[key];
  return (Array.isArray(value) ? value[0] : value)?.trim() ?? "";
}

export function pageParam(params: SearchParams): number {
  const value = Number.parseInt(pick(params, "page"), 10);
  return Number.isFinite(value) && value > 0 ? Math.min(value, 1000) : 1;
}

export function pageRange(page: number, size: number = PAGE_SIZE): { from: number; to: number } {
  const from = (page - 1) * size;
  return { from, to: from + size - 1 };
}

export function totalPages(count: number, size: number = PAGE_SIZE): number {
  return Math.max(1, Math.ceil(count / size));
}

/** Makes free text safe to use inside PostgREST ilike / or() filters. */
export function searchTerm(raw: string): string {
  return raw.replace(/[%,()*\\_"']/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
}

export function oneOf<T extends string>(value: string, allowed: readonly T[]): T | "" {
  return (allowed as readonly string[]).includes(value) ? (value as T) : "";
}
