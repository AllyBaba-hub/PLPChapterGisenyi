import type { MemberStatus, UserRole } from "@/lib/rbac";

export const ROLE_LABELS: Record<UserRole, string> = {
  visitor: "Visitor",
  applicant: "Applicant",
  member: "Member",
  admin: "Administrator",
  super_admin: "Super administrator",
};

export const STATUS_LABELS: Record<MemberStatus, string> = {
  pending: "Pending approval",
  active: "Active",
  suspended: "Suspended",
};
