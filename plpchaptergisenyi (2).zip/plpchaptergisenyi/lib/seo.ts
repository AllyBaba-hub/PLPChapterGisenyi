import type { Metadata } from "next";
import type { ChapterSettings, EventSummary, NewsSummary } from "@/lib/public-data";
import { truncate } from "@/lib/utils";

export const SITE_NAME = "PLP Chapter Gisenyi";
export const PARENT_SITE_URL = "https://plpyouth.org";
export const DEFAULT_DESCRIPTION =
  "PLP Chapter Gisenyi is the Gisenyi (Rubavu District, Rwanda) chapter of Peace and Love Proclaimers, a youth-led organization working for peacebuilding, unity, reconciliation and youth leadership.";
export const SITE_KEYWORDS = [
  "PLP Chapter Gisenyi",
  "Peace and Love Proclaimers Gisenyi",
  "PLP Rubavu youth",
  "Gisenyi youth organization",
  "peacebuilding Rwanda",
  "youth leadership Rubavu",
];
export const DEFAULT_OG_IMAGE = {
  path: "/og-default.png",
  width: 1200,
  height: 630,
  alt: "PLP Chapter Gisenyi — Peace and Love Proclaimers, Gisenyi, Rubavu District, Rwanda",
};

type JsonObject = Record<string, unknown>;

/* -------------------------------------------------------------------- URLs */

export function getSiteUrl(): string {
  const explicit = process.env.NEXT_PUBLIC_SITE_URL;
  if (explicit) return explicit.replace(/\/+$/, "");
  const vercelHost = process.env.VERCEL_PROJECT_PRODUCTION_URL ?? process.env.VERCEL_URL;
  if (vercelHost) return `https://${vercelHost.replace(/\/+$/, "")}`;
  return "http://localhost:3000";
}

export function absoluteUrl(pathOrUrl: string = "/"): string {
  if (/^https?:\/\//i.test(pathOrUrl)) return pathOrUrl;
  return `${getSiteUrl()}${pathOrUrl.startsWith("/") ? pathOrUrl : `/${pathOrUrl}`}`;
}

export function organizationId(): string {
  return `${getSiteUrl()}/#organization`;
}

/* ---------------------------------------------------------------- metadata */

export interface PageSeoInput {
  title: string;
  description: string;
  path: string;
  image?: string | null;
  type?: "website" | "article";
  publishedTime?: string | null;
  modifiedTime?: string | null;
  /** Use the title as-is instead of the "%s | PLP Chapter Gisenyi" template. */
  absoluteTitle?: boolean;
}

export function buildMetadata(input: PageSeoInput): Metadata {
  const url = absoluteUrl(input.path);
  const description = truncate(input.description, 200);
  const fullTitle = input.absoluteTitle ? input.title : `${input.title} | ${SITE_NAME}`;
  const image = input.image
    ? { url: absoluteUrl(input.image), alt: input.title }
    : {
        url: absoluteUrl(DEFAULT_OG_IMAGE.path),
        width: DEFAULT_OG_IMAGE.width,
        height: DEFAULT_OG_IMAGE.height,
        alt: DEFAULT_OG_IMAGE.alt,
      };

  const openGraph =
    input.type === "article"
      ? {
          type: "article",
          url,
          siteName: SITE_NAME,
          title: fullTitle,
          description,
          locale: "en_GB",
          images: [image],
          publishedTime: input.publishedTime ?? undefined,
          modifiedTime: input.modifiedTime ?? undefined,
          authors: [SITE_NAME],
        }
      : {
          type: "website",
          url,
          siteName: SITE_NAME,
          title: fullTitle,
          description,
          locale: "en_GB",
          images: [image],
        };

  return {
    title: input.absoluteTitle ? { absolute: input.title } : input.title,
    description,
    alternates: { canonical: url },
    openGraph: openGraph as Metadata["openGraph"],
    twitter: {
      card: "summary_large_image",
      title: fullTitle,
      description,
      images: [image.url],
    },
  };
}

/* ---------------------------------------------------------------- JSON-LD */

export function jsonLdGraph(...nodes: JsonObject[]): JsonObject {
  return { "@context": "https://schema.org", "@graph": nodes };
}

export function organizationNode(settings: ChapterSettings): JsonObject {
  const base = getSiteUrl();
  const sameAs = [PARENT_SITE_URL, ...Object.values(settings.social_links)];

  return {
    "@type": "NGO",
    "@id": organizationId(),
    name: settings.chapter_name,
    alternateName: ["Peace and Love Proclaimers Gisenyi", "PLP Rubavu youth"],
    url: base,
    logo: { "@type": "ImageObject", url: absoluteUrl("/logo.png"), width: 512, height: 512 },
    image: absoluteUrl(DEFAULT_OG_IMAGE.path),
    description: settings.about_summary,
    email: settings.contact_email,
    ...(settings.contact_phone ? { telephone: settings.contact_phone } : {}),
    address: {
      "@type": "PostalAddress",
      addressLocality: "Gisenyi",
      addressRegion: "Rubavu District",
      addressCountry: "RW",
    },
    areaServed: { "@type": "AdministrativeArea", name: "Rubavu District, Rwanda" },
    parentOrganization: {
      "@type": "Organization",
      name: settings.parent_organization,
      url: PARENT_SITE_URL,
      foundingDate: "2007",
      foundingLocation: { "@type": "Country", name: "Rwanda" },
    },
    contactPoint: {
      "@type": "ContactPoint",
      contactType: "general inquiries",
      email: settings.contact_email,
      ...(settings.contact_phone ? { telephone: settings.contact_phone } : {}),
      availableLanguage: ["English", "Kinyarwanda", "French"],
    },
    knowsAbout: ["Peacebuilding", "Unity and reconciliation", "Youth leadership", "Community service"],
    sameAs,
  };
}

export function websiteNode(settings: ChapterSettings): JsonObject {
  return {
    "@type": "WebSite",
    "@id": `${getSiteUrl()}/#website`,
    url: getSiteUrl(),
    name: settings.chapter_name,
    description: settings.about_summary,
    inLanguage: "en",
    publisher: { "@id": organizationId() },
  };
}

export function pageNode(input: {
  type?: "WebPage" | "AboutPage" | "ContactPage" | "CollectionPage";
  name: string;
  description: string;
  path: string;
  items?: Array<{ url: string; name: string }>;
}): JsonObject {
  const url = absoluteUrl(input.path);
  return {
    "@type": input.type ?? "WebPage",
    "@id": `${url}#webpage`,
    url,
    name: input.name,
    description: truncate(input.description, 300),
    inLanguage: "en",
    isPartOf: { "@id": `${getSiteUrl()}/#website` },
    publisher: { "@id": organizationId() },
    ...(input.items && input.items.length > 0
      ? {
          mainEntity: {
            "@type": "ItemList",
            itemListElement: input.items.map((item, index) => ({
              "@type": "ListItem",
              position: index + 1,
              url: item.url,
              name: item.name,
            })),
          },
        }
      : {}),
  };
}

export function faqNode(faqs: Array<{ question: string; answer: string }>): JsonObject {
  return {
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: { "@type": "Answer", text: faq.answer },
    })),
  };
}

export function breadcrumbNode(items: Array<{ name: string; path: string }>): JsonObject {
  return {
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: absoluteUrl(item.path),
    })),
  };
}

export function eventNode(
  event: EventSummary & { description: string },
  settings: ChapterSettings
): JsonObject {
  const url = absoluteUrl(`/events/${event.slug}`);
  return {
    "@type": "Event",
    "@id": `${url}#event`,
    name: event.title,
    description: truncate(event.summary || event.description, 500),
    url,
    startDate: event.start_time,
    ...(event.end_time ? { endDate: event.end_time } : {}),
    eventStatus: "https://schema.org/EventScheduled",
    eventAttendanceMode: "https://schema.org/OfflineEventAttendanceMode",
    location: {
      "@type": "Place",
      name: event.location,
      address: {
        "@type": "PostalAddress",
        addressLocality: "Gisenyi",
        addressRegion: "Rubavu District",
        addressCountry: "RW",
      },
    },
    image: [event.cover_image_url ? absoluteUrl(event.cover_image_url) : absoluteUrl(DEFAULT_OG_IMAGE.path)],
    organizer: {
      "@type": "NGO",
      "@id": organizationId(),
      name: settings.chapter_name,
      url: getSiteUrl(),
    },
    ...(event.max_capacity ? { maximumAttendeeCapacity: event.max_capacity } : {}),
    inLanguage: "en",
    potentialAction: {
      "@type": "RegisterAction",
      name: "Register for this event as a PLP Chapter Gisenyi member",
      target: absoluteUrl(`/login?next=${encodeURIComponent("/member/events")}`),
    },
  };
}

export function newsArticleNode(
  article: NewsSummary & { content: string },
  settings: ChapterSettings
): JsonObject {
  const url = absoluteUrl(`/news/${article.slug}`);
  const published = article.published_at ?? article.created_at;
  return {
    "@type": "NewsArticle",
    "@id": `${url}#article`,
    headline: truncate(article.title, 110),
    description: truncate(article.excerpt, 300),
    url,
    mainEntityOfPage: { "@type": "WebPage", "@id": url },
    datePublished: published,
    dateModified: article.updated_at,
    image: [article.cover_image_url ? absoluteUrl(article.cover_image_url) : absoluteUrl(DEFAULT_OG_IMAGE.path)],
    author: { "@type": "NGO", "@id": organizationId(), name: settings.chapter_name, url: getSiteUrl() },
    publisher: {
      "@type": "NGO",
      "@id": organizationId(),
      name: settings.chapter_name,
      logo: { "@type": "ImageObject", url: absoluteUrl("/logo.png") },
    },
    inLanguage: "en",
    wordCount: article.content.split(/\s+/).filter(Boolean).length,
  };
}
