export const MEDIA_BUCKET = "chapter-media";
/** Free-tier discipline: every uploaded photo is compressed to at most 250 KB. */
export const MAX_UPLOAD_BYTES = 250 * 1024;

export function avatarFolder(userId: string): string {
  return `avatars/${userId}`;
}

/** Unique file name per upload, so replacing an avatar never needs an UPDATE policy. */
export function newAvatarPath(userId: string, extension: "webp" | "jpg"): string {
  return `${avatarFolder(userId)}/${Date.now()}.${extension}`;
}

export function isOwnAvatarPath(path: unknown, userId: string): path is string {
  if (typeof path !== "string") return false;
  const pattern = new RegExp(`^avatars/${userId}/[A-Za-z0-9._-]+\\.(webp|jpg|jpeg|png)$`);
  return pattern.test(path);
}

/** Extracts the object path from a public Supabase Storage URL, or null. */
export function storagePathFromPublicUrl(url: string | null | undefined): string | null {
  if (!url) return null;
  const marker = `/storage/v1/object/public/${MEDIA_BUCKET}/`;
  const index = url.indexOf(marker);
  if (index === -1) return null;
  try {
    return decodeURIComponent(url.slice(index + marker.length).split("?")[0]);
  } catch {
    return null;
  }
}

export type CoverFolder = "events" | "news" | "gallery";

/** Validates a browser-uploaded admin image path such as events/{uuid}.webp. */
export function isAdminImagePath(path: unknown, folder: CoverFolder): path is string {
  if (typeof path !== "string") return false;
  const pattern = new RegExp(`^${folder}/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\\.(webp|jpg)$`);
  return pattern.test(path);
}
