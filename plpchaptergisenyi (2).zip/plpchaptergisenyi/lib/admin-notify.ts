import { logEmailNotification } from "@/app/(admin)/admin/_actions/notifications";
import { EmailJsError, isEmailJsConfigured, sendAccountNotice, type AccountNoticeInput } from "@/lib/emailjs";

/**
 * Sends an account/status notice through EmailJS from the admin's browser and records the
 * result in the audit log so monthly free-tier usage can be tracked.
 */
export async function sendAccountNoticeAndLog(
  input: AccountNoticeInput,
  entity: { type: string; id: string }
): Promise<{ sent: boolean; message: string }> {
  if (!isEmailJsConfigured("account")) {
    return { sent: false, message: "Email isn't configured, so no notice was emailed." };
  }

  try {
    await sendAccountNotice(input);
    await logEmailNotification({
      template: "account",
      kind: input.kind,
      entityType: entity.type,
      entityId: entity.id,
      requests: 1,
      recipients: 1,
    });
    return { sent: true, message: "An email notice was sent." };
  } catch (error) {
    const known = error instanceof EmailJsError;
    await logEmailNotification({
      template: "account",
      kind: input.kind,
      entityType: entity.type,
      entityId: entity.id,
      requests: 0,
      recipients: 0,
      failedRecipients: 1,
      error: known ? error.code : "unknown",
    }).catch(() => undefined);
    return {
      sent: false,
      message: known ? `The change was saved, but the email wasn't sent: ${error.message}` : "The change was saved, but the email couldn't be sent.",
    };
  }
}
