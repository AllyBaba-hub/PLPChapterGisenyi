import type { MemberStatus, UserRole } from "@/lib/rbac";

/** Roles an administrator can pick in the UI. */
export const ASSIGNABLE_ROLES = ["member", "admin", "super_admin"] as const;
export type AssignableRole = (typeof ASSIGNABLE_ROLES)[number];
export const MANAGEABLE_STATUSES = ["active", "suspended"] as const;
export type ManageableStatus = (typeof MANAGEABLE_STATUSES)[number];

export interface RuleActor {
  id: string;
  role: UserRole;
}

export interface RuleTarget {
  id: string;
  role: UserRole;
  status: MemberStatus;
}

export interface RuleResult {
  allowed: boolean;
  reason?: string;
}

export function isAdminLevel(role: UserRole): boolean {
  return role === "admin" || role === "super_admin";
}

const allow: RuleResult = { allowed: true };
const deny = (reason: string): RuleResult => ({ allowed: false, reason });

/**
 * Mirrors the database trigger enforce_role_hierarchy(), so the UI and server
 * actions explain a refusal before the database has to reject it.
 */
export function checkRoleChange(actor: RuleActor, target: RuleTarget, newRole: UserRole): RuleResult {
  if (actor.id === target.id) return deny("You can't change your own role.");
  if (target.status === "pending") {
    return deny("Approve this person's application before changing their role.");
  }
  if (newRole === target.role) return deny("That is already their role.");
  if ((isAdminLevel(target.role) || isAdminLevel(newRole)) && actor.role !== "super_admin") {
    return deny("Only a super administrator can change administrator roles.");
  }
  return allow;
}

export function checkStatusChange(actor: RuleActor, target: RuleTarget, newStatus: ManageableStatus): RuleResult {
  if (actor.id === target.id) return deny("You can't change your own status.");
  if (target.status === "pending") {
    return deny("Approve this person's application to activate their account.");
  }
  if (newStatus === target.status) return deny(`That account is already ${newStatus}.`);
  if (isAdminLevel(target.role) && actor.role !== "super_admin") {
    return deny("Only a super administrator can suspend or reactivate an administrator.");
  }
  return allow;
}

/** Social profiles the chapter can link to from the footer and structured data. */
export const SOCIAL_KEYS = ["facebook", "instagram", "x", "youtube", "tiktok", "linkedin"] as const;
