const TIME_ZONE = "Africa/Kigali";
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const DEFAULT_EVENT_DURATION_MS = 3 * 60 * 60 * 1000;

export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

export function isUuid(value: string): boolean {
  return UUID_PATTERN.test(value);
}

function toDate(value: string | Date | null | undefined): Date | null {
  if (!value) return null;
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function formatter(options: Intl.DateTimeFormatOptions): Intl.DateTimeFormat {
  return new Intl.DateTimeFormat("en-GB", { timeZone: TIME_ZONE, ...options });
}

function dayKey(date: Date): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(date);
}

function timeOf(date: Date): string {
  return formatter({ hour: "2-digit", minute: "2-digit", hour12: false }).format(date);
}

/** e.g. "5 December 2026" in Rwanda time. */
export function formatDate(value: string | Date | null | undefined): string {
  const date = toDate(value);
  return date ? formatter({ dateStyle: "long" }).format(date) : "";
}

/** e.g. "Saturday 5 December 2026, 09:00–12:00" in Rwanda time. */
export function formatEventWhen(
  start: string | Date,
  end?: string | Date | null
): string {
  const startDate = toDate(start);
  if (!startDate) return "";
  const endDate = toDate(end);
  const full = formatter({ dateStyle: "full" });

  if (!endDate) return `${full.format(startDate)}, ${timeOf(startDate)}`;
  if (dayKey(startDate) === dayKey(endDate)) {
    return `${full.format(startDate)}, ${timeOf(startDate)}–${timeOf(endDate)}`;
  }
  return `${full.format(startDate)}, ${timeOf(startDate)} – ${full.format(endDate)}, ${timeOf(endDate)}`;
}

/** Day number and short month for date badges. */
export function getDateParts(value: string | Date): { day: string; month: string; year: string } {
  const date = toDate(value);
  if (!date) return { day: "", month: "", year: "" };
  return {
    day: formatter({ day: "numeric" }).format(date),
    month: formatter({ month: "short" }).format(date),
    year: formatter({ year: "numeric" }).format(date),
  };
}

export function truncate(text: string, max: number): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (clean.length <= max) return clean;
  const cut = clean.slice(0, max - 1);
  const lastSpace = cut.lastIndexOf(" ");
  return `${(lastSpace > max * 0.6 ? cut.slice(0, lastSpace) : cut).trimEnd()}…`;
}

export function toParagraphs(text: string): string[] {
  return text
    .replace(/\r\n/g, "\n")
    .split(/\n{2,}/)
    .map((block) => block.trim())
    .filter(Boolean);
}

export function eventEndsAt(event: { start_time: string; end_time: string | null }): Date {
  const end = toDate(event.end_time);
  if (end) return end;
  const start = toDate(event.start_time) ?? new Date(0);
  return new Date(start.getTime() + DEFAULT_EVENT_DURATION_MS);
}

/** Splits events into upcoming/ongoing (soonest first) and past (latest first). */
export function splitEvents<T extends { start_time: string; end_time: string | null }>(
  events: T[],
  now: Date = new Date()
): { upcoming: T[]; past: T[] } {
  const upcoming: T[] = [];
  const past: T[] = [];
  for (const event of events) {
    (eventEndsAt(event) >= now ? upcoming : past).push(event);
  }
  upcoming.sort((a, b) => a.start_time.localeCompare(b.start_time));
  past.sort((a, b) => b.start_time.localeCompare(a.start_time));
  return { upcoming, past };
}

const SOCIAL_LABELS: Record<string, string> = {
  facebook: "Facebook",
  instagram: "Instagram",
  x: "X",
  twitter: "X",
  youtube: "YouTube",
  tiktok: "TikTok",
  linkedin: "LinkedIn",
  whatsapp: "WhatsApp",
  telegram: "Telegram",
};

export function socialLabel(key: string): string {
  const lower = key.toLowerCase();
  return SOCIAL_LABELS[lower] ?? lower.charAt(0).toUpperCase() + lower.slice(1);
}
