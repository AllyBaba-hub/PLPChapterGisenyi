# Deployment checklist and manual QA script

Use this document before the first public launch and again after any major change. Tick each box as you go. A single failed item in Part 4 (security boundaries) should block launch.

**What you need before you start**

- The deployed site address (called `https://YOUR-DOMAIN` below).
- Access to the Supabase dashboard (SQL Editor, Authentication, Storage), the Vercel project, and the EmailJS dashboard.
- Five test identities. Use plus-addressing on one mailbox if you like (`you+admin@gmail.com`, `you+member@gmail.com`, …):

  | Name | Used for |
  | --- | --- |
  | **SuperAdmin** | The bootstrapped super administrator |
  | **Admin2** | A second administrator promoted by SuperAdmin |
  | **MemberA** | An approved member |
  | **MemberB** | A second approved member (capacity test) |
  | **Applicant** | Someone who applies and is left pending |

---

## Part 1. Pre-launch checklist

### 1.1 Supabase project

- [ ] All seven migrations were run once, in order (`…120100`, `…120300`, `…120400`, `…120500`, `…120600`, `…120700`, `…120800`).
- [ ] **RLS is on for every table.** Run in the SQL Editor:

  ```sql
  SELECT tablename, rowsecurity
  FROM pg_tables
  WHERE schemaname = 'public'
  ORDER BY tablename;
  ```

  Expect `rowsecurity = true` for: `announcement_reads`, `announcements`, `audit_logs`, `chapter_settings`, `contact_messages`, `event_registrations`, `events`, `gallery_items`, `membership_applications`, `news_articles`, `profiles`.

- [ ] **Policies exist.** Run:

  ```sql
  SELECT tablename, policyname, cmd
  FROM pg_policies
  WHERE schemaname = 'public'
  ORDER BY tablename, cmd, policyname;
  ```

  Check specifically:
  - `event_registrations` has **SELECT** (own or admin), **UPDATE** (admin) and **DELETE** ("Admins can delete registrations") policies and **no INSERT policy**.
  - `membership_applications` and `contact_messages` each have an **INSERT** policy open to anyone.
  - `audit_logs` has SELECT for admins and an INSERT policy.
  - `chapter_settings` has SELECT for everyone and UPDATE for admins only.

- [ ] **Triggers exist.** Run:

  ```sql
  SELECT event_object_schema, event_object_table, trigger_name
  FROM information_schema.triggers
  WHERE event_object_schema IN ('public', 'auth')
  ORDER BY event_object_schema, event_object_table, trigger_name;
  ```

  Expect, among others: `on_auth_user_created` (on `auth.users`), and on `public.profiles`: `trg_profiles_enforce_hierarchy`, `trg_profiles_protect`, `trg_profiles_updated_at`.

- [ ] **Functions exist and are not callable by visitors.** Run:

  ```sql
  SELECT routine_name FROM information_schema.routines
  WHERE routine_schema = 'public'
    AND routine_name IN ('is_admin','is_active_member','is_super_admin','approve_membership_application',
                         'register_for_event','cancel_event_registration','event_registration_counts',
                         'generate_member_code','enforce_role_hierarchy','protect_profile_fields')
  ORDER BY routine_name;   -- expect 10 rows

  SELECT has_function_privilege('anon', 'public.register_for_event(uuid)', 'execute') AS anon_can_register,
         has_function_privilege('authenticated', 'public.register_for_event(uuid)', 'execute') AS member_can_register;
  -- expect: false, true
  ```

- [ ] **Chapter settings row exists:** `SELECT chapter_name, applications_open, contact_email FROM public.chapter_settings;` returns one row.
- [ ] **A super administrator exists:** `SELECT email, role, status, member_code FROM public.profiles WHERE role = 'super_admin';` returns at least one active row (see the README's bootstrap steps).

### 1.2 Supabase Storage

- [ ] Bucket settings are correct:

  ```sql
  SELECT id, public, file_size_limit, allowed_mime_types
  FROM storage.buckets WHERE id = 'chapter-media';
  ```

  Expect `public = true`, `file_size_limit = 524288`, and `{image/jpeg,image/png,image/webp}`.

- [ ] Storage policies exist:

  ```sql
  SELECT policyname, cmd FROM pg_policies
  WHERE schemaname = 'storage' AND tablename = 'objects'
  ORDER BY cmd, policyname;
  ```

  Expect SELECT (public read), two INSERT policies (admins anywhere; members only under their own `avatars/{user id}/`), and a DELETE policy (admins, or the owner for their own avatar).

### 1.3 Supabase Auth

- [ ] **Site URL** is the production address.
- [ ] **Redirect URLs** include `https://YOUR-DOMAIN/reset-password` and `https://YOUR-DOMAIN/login` (plus the `localhost` equivalents for development).
- [ ] **Confirm email** is on, and **minimum password length** is 8.
- [ ] **Custom SMTP** is configured (the built-in sender is too limited for launch).
- [ ] Send yourself a test confirmation and a test password-reset email and confirm both arrive and the links open the right pages.

### 1.4 Vercel

- [ ] All eight environment variables are set for Production: `NEXT_PUBLIC_SITE_URL`, `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `NEXT_PUBLIC_EMAILJS_SERVICE_ID`, `NEXT_PUBLIC_EMAILJS_PUBLIC_KEY`, `NEXT_PUBLIC_EMAILJS_ACTIVITY_TEMPLATE_ID`, `NEXT_PUBLIC_EMAILJS_ACCOUNT_TEMPLATE_ID`.
- [ ] `SUPABASE_SERVICE_ROLE_KEY` is **not** prefixed with `NEXT_PUBLIC_`.
- [ ] The project was **redeployed after the last environment change** (public variables are fixed at build time).
- [ ] The build log shows no errors and no "Supabase not configured" messages.
- [ ] The custom domain works over HTTPS and `NEXT_PUBLIC_SITE_URL` matches it exactly.
- [ ] **Settings → Cron Jobs** lists `/api/health` (daily). Open `https://YOUR-DOMAIN/api/health`: it returns `{"ok":true,"database":"up",…}`.
- [ ] The service-role key is not in the browser code. From a local production build, run `grep -r "service_role" .next/static` and also search for the first 20 characters of your real service-role key: neither should match anything.

### 1.5 EmailJS

- [ ] The two templates exist and use the variable names from the README (compare against the table there).
- [ ] The four IDs and the public key in Vercel match the dashboard.
- [ ] The allowed origins are restricted to your domain (if your plan supports it).
- [ ] After Part 3 (the approval flow), confirm the account-notice email arrived, was not in spam, and shows the member ID and sign-in button correctly.
- [ ] After Part 4.4 (the event alert), confirm the alert email arrived with the recipients in **Bcc** (other members' addresses must not be visible), and that Admin → Settings shows the usage counter increased.

### 1.6 Content and SEO readiness

- [ ] Admin → Settings: chapter name, location, contact email, phone, about summary and social links are filled in.
- [ ] At least one published event, news article and gallery item exist, so public pages do not launch empty.
- [ ] `https://YOUR-DOMAIN/llms.txt` lists the public routes and the correct contact email.
- [ ] Submit `https://YOUR-DOMAIN/sitemap.xml` to Google Search Console and Bing Webmaster Tools.

---

## Part 2. Manual QA script: public site, SEO and GEO

Run signed out, in a private browser window. Tick the box only if the **Expected** result matches exactly.

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 2.1 | Open `/` | Home loads with the chapter name, summary, "Next event" panel, values, news, FAQ and join call-to-action. No console errors | [ ] |
| 2.2 | Use header links: About, Events, News, Gallery, Contact | Each loads; the current link is highlighted | [ ] |
| 2.3 | Resize to phone width; open the menu button | Menu opens and closes; Escape closes it; no horizontal scrolling | [ ] |
| 2.4 | Press Tab on a fresh page load | "Skip to main content" appears first and works | [ ] |
| 2.5 | View page source on `/` | `<html lang="en" data-theme="light">`; one `<title>`; a `canonical` link to your domain; `og:title`, `og:image`, `twitter:card` | [ ] |
| 2.6 | In the source of `/`, find `application/ld+json` | Contains an `NGO` with name, address (Gisenyi, Rubavu District, RW), `parentOrganization`, plus `WebSite` and `FAQPage` | [ ] |
| 2.7 | Open `/about` | Mission, values, FAQ; JSON-LD includes `AboutPage` and `FAQPage` | [ ] |
| 2.8 | Open `/events` | Upcoming and past sections; cards show date badge, place and summary | [ ] |
| 2.9 | Open an event, then try the same event by its UUID in the address bar | The event page loads; the UUID address redirects to the slug address | [ ] |
| 2.10 | View source of an event page | JSON-LD `Event` with `startDate`, `location`, `organizer` and a `RegisterAction` | [ ] |
| 2.11 | Open `/news` and an article | List and article load; JSON-LD `NewsArticle` with `datePublished` | [ ] |
| 2.12 | Open `/gallery`; use the Photos and Videos filters; click a photo; press Escape | Filters work; the photo opens in a viewer and closes | [ ] |
| 2.13 | Press play on a video | Only then does a YouTube player load (privacy-friendly domain `youtube-nocookie.com`) | [ ] |
| 2.14 | Open `/sitemap.xml` | Lists `/`, `/about`, `/events`, `/news`, `/gallery`, `/join`, `/contact` and every published event and article by slug. No drafts | [ ] |
| 2.15 | Open `/robots.txt` | Allows `/`; disallows `/member/`, `/admin/`, `/api/`; points to the sitemap | [ ] |
| 2.16 | Open `/llms.txt` | Plain text summary with the public routes | [ ] |
| 2.17 | View source of `/login` and `/forgot-password` | Contain `noindex` | [ ] |
| 2.18 | Open `/this-page-does-not-exist` | Branded 404 with the header and footer | [ ] |
| 2.19 | Open `/contact`; submit with empty fields | Clear inline errors; focus moves to the first problem | [ ] |
| 2.20 | Submit a valid contact message | "Message sent" appears. (Check it in Admin → Messages during Part 3) | [ ] |
| 2.21 | Run Lighthouse (mobile) on `/` and `/events` | Performance, Accessibility, Best Practices and SEO are all green (90+) | [ ] |
| 2.22 | Paste a public page URL into the Google Rich Results Test / Schema Markup Validator | `Event`, `FAQ` and `Organization` data parse without errors | [ ] |

---

## Part 3. Manual QA script: join flow, super admin bootstrap and approval

### 3.1 Application flow (`/join`)

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 3.1.1 | Open `/join` | Steps, form and header render | [ ] |
| 3.1.2 | Submit the empty form | Inline errors for every required field; nothing is created | [ ] |
| 3.1.3 | Fill in **Applicant** and submit | "Application received". If email confirmation is on, the page says to confirm your email | [ ] |
| 3.1.4 | In Supabase, run `SELECT email, status, user_id FROM membership_applications ORDER BY created_at DESC LIMIT 1;` | New row: `status = pending`, `user_id` filled | [ ] |
| 3.1.5 | Open the confirmation email and click the link | Lands on `/login` | [ ] |
| 3.1.6 | Submit `/join` again using the **same email** | Message that the email already has an account, with sign-in and reset links. No duplicate application | [ ] |
| 3.1.7 | Sign in as **Applicant** | Redirected to `/join?notice=pending-approval` with the "waiting for approval" notice | [ ] |
| 3.1.8 | While signed in as Applicant, visit `/member` and `/admin` | Both bounce to `/join?notice=pending-approval` | [ ] |
| 3.1.9 | On `/join` signed in, check the top of the form | Shows "You are signed in as …" with a **Not you? Sign out** button | [ ] |
| 3.1.10 | Sign out. Create **MemberA** and **MemberB** the same way (`/join`, confirm email) and leave them pending | Two more pending applications | [ ] |

### 3.2 Super admin bootstrap

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 3.2.1 | Create the SuperAdmin user and run the bootstrap `UPDATE` from the README | One row updated; verification query shows `super_admin`, `active`, and a member ID like `PLP-GIS-2026-0001` | [ ] |
| 3.2.2 | Sign in as SuperAdmin at `/login` | Lands on `/admin` | [ ] |
| 3.2.3 | Look at the overview and the sidebar | Pending applications count is 3; the Applications badge shows 3; Reports is in the sidebar | [ ] |
| 3.2.4 | Open Admin → Messages | The message from step 2.20 is listed as **Unread**. Opening it marks it read; "Reply by email" opens your mail app | [ ] |

### 3.3 Approval flow

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 3.3.1 | Admin → Applications → open MemberA's application | Full details; the Decision section shows notes, an "Email the applicant" checkbox, Approve and Reject | [ ] |
| 3.3.2 | Click **Approve** (email checkbox on) | Success message; "An email notice was sent."; status becomes Approved | [ ] |
| 3.3.3 | Check Supabase: `SELECT email, role, status, member_code, joined_at FROM profiles WHERE email = 'MemberA email';` | `member`, `active`, a new `PLP-GIS-YYYY-NNNN`, `joined_at` set | [ ] |
| 3.3.4 | Check MemberA's mailbox | Approval email with the member ID and a sign-in button | [ ] |
| 3.3.5 | Admin → Audit logs, filter action `APPLICATION_APPROVED` | An entry for MemberA by SuperAdmin; also an `EMAIL_NOTIFICATION_SENT` entry | [ ] |
| 3.3.6 | Approve MemberB without emailing | Approved; no email checkbox usage recorded | [ ] |
| 3.3.7 | Reject the Applicant's application with a note (email on) | "Application rejected"; the rejection email contains the note; the application cannot be rejected again | [ ] |
| 3.3.8 | Sign in as MemberA | Lands on `/member`. Dashboard greets MemberA; status Active; member ID shown | [ ] |
| 3.3.9 | Open `/member/card` | Card shows name, member ID, role, status, QR code and back side. **Print or save as PDF** hides the sidebar and top bar | [ ] |
| 3.3.10 | Admin → Members | MemberA and MemberB appear as Active members | [ ] |

### 3.4 Reports page

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 3.4.1 | Admin → Reports | Membership, Events and Communication sections load with numbers matching what you did above | [ ] |
| 3.4.2 | Click **Print or save as PDF**; choose "Save as PDF" | Preview shows a report header (chapter name, period, generated time); **no sidebar, no top bar, no buttons**; sections do not split awkwardly; bars keep their colours | [ ] |
| 3.4.3 | Pick a year in the period filter | Event figures change to that year; membership figures stay the same | [ ] |
| 3.4.4 | Check the EmailJS usage block | Shows the emails sent so far in this QA run | [ ] |

---

## Part 4. Manual QA script: events, RSVP, attendance and notifications

### 4.1 Create and publish an event (SuperAdmin)

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 4.1.1 | Admin → Events → New event. Fill in the details, **capacity 2**, start a few minutes from now (Rwanda time), choose a cover photo of several MB | The photo is compressed in the browser; preview appears | [ ] |
| 4.1.2 | Save with **Published** ticked | Redirects to the edit page with "Event created." | [ ] |
| 4.1.3 | In Storage → `chapter-media` → `events/` | The cover file is 250 KB or smaller | [ ] |
| 4.1.4 | Open the event on the public site immediately | It appears right away (no 5-minute wait), with the cover image | [ ] |
| 4.1.5 | Save a second, **unpublished** draft event | It does not appear on `/events`, in `/sitemap.xml`, or in the member portal | [ ] |
| 4.1.6 | Try an end time earlier than the start | Inline error "The end must be after the start" | [ ] |

### 4.2 RSVP and capacity (members)

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 4.2.1 | As MemberA open `/member/events` | The event shows "0 of 2 places taken" and a **Register** button | [ ] |
| 4.2.2 | Click **Register** | "You're registered"; count becomes 1 of 2 | [ ] |
| 4.2.3 | As MemberB, register | Count becomes 2 of 2 | [ ] |
| 4.2.4 | As SuperAdmin, approve a third member (or use Admin2 after Part 5) and sign in as them | The event shows **Event full**; Register is disabled | [ ] |
| 4.2.5 | **Server-side capacity check.** In SQL Editor, simulate the third member (replace the UUID with theirs):<br>`BEGIN; SET LOCAL ROLE authenticated; SELECT set_config('request.jwt.claim.sub', 'THIRD-MEMBER-UUID', true); SELECT set_config('request.jwt.claims', '{"sub":"THIRD-MEMBER-UUID","role":"authenticated"}', true); SELECT public.register_for_event('EVENT-UUID'); ROLLBACK;` | Returns `full` | [ ] |
| 4.2.6 | MemberB clicks **Cancel registration** | Count drops to 1 of 2 and the button changes back to Register | [ ] |
| 4.2.7 | Admin → Audit logs, action `EVENT_REGISTERED` and `EVENT_UNREGISTERED` | Entries for each action | [ ] |

### 4.3 Attendance and history

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 4.3.1 | SuperAdmin: Admin → Events → **Registrations** for the event | Lists MemberA with an Attended checkbox | [ ] |
| 4.3.2 | Tick MemberA as attended | Checkbox saves; counter reads "1 of 1 marked as attended" | [ ] |
| 4.3.3 | Once the event has started, MemberA clicks Cancel (if still shown) or calls cancel via SQL as in 4.2.5 using `public.cancel_event_registration('EVENT-UUID')` | Returns `closed`; the registration stays | [ ] |
| 4.3.4 | MemberA opens `/member/history` after the event has ended | Shows the event as **Attended**; summary counts and attendance rate are correct | [ ] |
| 4.3.5 | Admin → Reports | Registrations and attendance rate include this event | [ ] |

### 4.4 Announcements and email alerts

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 4.4.1 | Admin → Announcements: create an **Urgent** announcement, visible to members | Appears in the list | [ ] |
| 4.4.2 | As MemberA, check the sidebar | Announcements shows an unread badge of 1; the dashboard counts 1 unread | [ ] |
| 4.4.3 | Open `/member/announcements` | Urgent item is first, marked Unread. Opening or viewing it marks it read; the badge clears | [ ] |
| 4.4.4 | As MemberB, switch off **Chapter email alerts** in `/member/settings` | "Email notifications are off." | [ ] |
| 4.4.5 | As SuperAdmin, on the event or announcement click **Email members about this** | A review panel shows the recipient count (MemberB is excluded), the requests needed and the quota | [ ] |
| 4.4.6 | Confirm the send | "Alert sent to N members"; MemberA receives the email; other recipients are in Bcc; MemberB receives nothing | [ ] |
| 4.4.7 | Admin → Settings | The EmailJS usage counter increased | [ ] |
| 4.4.8 | Hide the announcement (unpublish) | It disappears from the member portal; **Email members** is disabled with an explanation | [ ] |

### 4.5 Content management

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 4.5.1 | Create a news article, publish it | Appears on `/news` and in the sitemap immediately | [ ] |
| 4.5.2 | Edit the title and slug | The old address no longer resolves; the new one does | [ ] |
| 4.5.3 | Unpublish it | Disappears from `/news` and the sitemap | [ ] |
| 4.5.4 | Gallery: upload a large photo with a title and description | Stored at 250 KB or smaller under `gallery/`; appears on `/gallery` | [ ] |
| 4.5.5 | Gallery: add a YouTube link | Appears as a video thumbnail; no file is stored in Storage | [ ] |
| 4.5.6 | Gallery: paste a non-YouTube link | Error asking for a YouTube link | [ ] |
| 4.5.7 | Delete a gallery photo | Removed from the page **and** from Storage | [ ] |
| 4.5.8 | Delete the draft event | Removed; its cover image is removed from Storage | [ ] |
| 4.5.9 | Admin → Settings: change the about summary and turn **Accept new applications** off | `/` shows the new summary; `/join` says applications are closed. Turn it back on afterwards | [ ] |

---

## Part 5. Manual QA script: security boundaries

Run these after Parts 3 and 4. Every row must show the **Expected** result.

### 5.1 Route protection

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 5.1.1 | Signed out, open `/member` and `/admin/members` | Redirected to `/login?next=…` | [ ] |
| 5.1.2 | Sign in from that page | Returned to the page you asked for | [ ] |
| 5.1.3 | Open `/login?next=//evil.example` and `/login?next=https://evil.example`, then sign in | You land on your normal home area, never on the external address | [ ] |
| 5.1.4 | As MemberA, open `/admin` | Redirected to `/member?error=forbidden` with a notice | [ ] |
| 5.1.5 | As SuperAdmin, **suspend** MemberB (Admin → Members → Manage → Suspend) | Success. MemberB's next request is blocked | [ ] |
| 5.1.6 | As MemberB (already signed in), reload `/member` | Signed out and sent to `/login?error=suspended` | [ ] |
| 5.1.7 | Sign in again as MemberB | Message that the account is suspended; no access | [ ] |
| 5.1.8 | Reactivate MemberB | MemberB can sign in again | [ ] |
| 5.1.9 | Pending or rejected Applicant opens `/member` | Sent to `/join?notice=pending-approval` | [ ] |

### 5.2 Roles and hierarchy

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 5.2.1 | As SuperAdmin promote MemberA to **Administrator** (call this **Admin2**) | Success; audit entry `ROLE_CHANGED` | [ ] |
| 5.2.2 | Sign in as Admin2 | Can open `/admin`; sidebar and overview load | [ ] |
| 5.2.3 | As Admin2 open Admin → Members → Manage on a normal member | The role dropdown is available only for non-administrator changes; changing administrator roles is explained as "Only a super administrator…" | [ ] |
| 5.2.4 | As Admin2 open the SuperAdmin's entry | Role and status controls are locked | [ ] |
| 5.2.5 | As Admin2 open your own entry | "You can't change your own role" | [ ] |
| 5.2.6 | **Database-level escalation test** (SQL Editor, replace UUIDs with Admin2's): `BEGIN; SET LOCAL ROLE authenticated; SELECT set_config('request.jwt.claim.sub','ADMIN2-UUID',true); SELECT set_config('request.jwt.claims','{"sub":"ADMIN2-UUID","role":"authenticated"}',true); UPDATE public.profiles SET role='super_admin' WHERE id='ADMIN2-UUID'; ROLLBACK;` | Error: "You cannot change your own role or status" | [ ] |
| 5.2.7 | Same test, but Admin2 tries to promote another member to `admin` | Error: "Only a super administrator can change administrator roles or accounts" | [ ] |
| 5.2.8 | As the only SuperAdmin try to demote or suspend yourself | Blocked (own role / last super administrator) | [ ] |
| 5.2.9 | Member-privilege test (SQL Editor, as MemberB): `BEGIN; SET LOCAL ROLE authenticated; SELECT set_config('request.jwt.claim.sub','MEMBERB-UUID',true); SELECT set_config('request.jwt.claims','{"sub":"MEMBERB-UUID","role":"authenticated"}',true); UPDATE public.profiles SET role='admin', member_code='PLP-GIS-2099-9999' WHERE id='MEMBERB-UUID'; SELECT role, member_code FROM public.profiles WHERE id='MEMBERB-UUID'; ROLLBACK;` | Role and member code are unchanged | [ ] |

### 5.3 Data access (row-level security)

Run each block in the SQL Editor; every one ends with `ROLLBACK;`.

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 5.3.1 | As **anon**: `BEGIN; SET LOCAL ROLE anon; SELECT count(*) FROM public.membership_applications; SELECT count(*) FROM public.contact_messages; SELECT count(*) FROM public.profiles; SELECT count(*) FROM public.audit_logs; ROLLBACK;` | All four counts are `0` | [ ] |
| 5.3.2 | As **anon**: `SELECT count(*) FROM public.events WHERE is_published = false;` (inside a rolled-back `SET LOCAL ROLE anon` block) | `0`. Unpublished events and news are invisible | [ ] |
| 5.3.3 | As **MemberA** (simulate as in 4.2.5): `INSERT INTO public.event_registrations (event_id, user_id) VALUES ('EVENT-UUID', 'MEMBERA-UUID');` | Denied (no INSERT policy; registrations go through the function) | [ ] |
| 5.3.4 | As **MemberA**: `DELETE FROM public.event_registrations WHERE user_id = 'MEMBERA-UUID';` | Deletes nothing (history is protected) | [ ] |
| 5.3.5 | As **MemberA**: `SELECT count(*) FROM public.event_registrations;` | Only their own rows are counted | [ ] |
| 5.3.6 | As **MemberA**: `SELECT * FROM public.audit_logs;` | No rows | [ ] |

### 5.4 Storage

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 5.4.1 | As MemberA upload a profile photo (Profile page) | Works; the file lands in `avatars/{MemberA id}/` and is 250 KB or smaller | [ ] |
| 5.4.2 | Replace the photo | The old file is removed from Storage; only one file remains in that folder | [ ] |
| 5.4.3 | Try a PDF or a 20 MB image as a profile photo | Rejected with a clear message before upload | [ ] |
| 5.4.4 | In Storage, try uploading a file bigger than 512 KB, or a non-image file, directly to the bucket | Rejected by the bucket rules | [ ] |

### 5.5 API and request hardening

Run from a terminal. Replace `YOUR-DOMAIN`.

| # | Command | Expected | ✔ |
| --- | --- | --- | --- |
| 5.5.1 | `curl -i https://YOUR-DOMAIN/api/members/export` | `401` JSON, no data | [ ] |
| 5.5.2 | Signed in as a member, open `https://YOUR-DOMAIN/api/members/export` in the browser | `403` | [ ] |
| 5.5.3 | Signed in as an admin, open the same address | A CSV downloads; opening it in a spreadsheet shows no formulas run. Audit logs show `MEMBERS_EXPORTED` | [ ] |
| 5.5.4 | `curl -i -X POST https://YOUR-DOMAIN/api/auth/failed-login -H 'Content-Type: application/json' -d '{"email":"a@b.co"}'` | `403` (no matching site origin) | [ ] |
| 5.5.5 | `curl -i -X POST https://YOUR-DOMAIN/api/events/register -H 'Content-Type: application/json' -H 'Origin: https://YOUR-DOMAIN' -d '{}'` | `401` | [ ] |
| 5.5.6 | Repeat a failed login five or more times quickly in the browser | The sixth report is rate-limited (the login still shows the normal error) | [ ] |
| 5.5.7 | `curl -I https://YOUR-DOMAIN/` | Headers include `x-content-type-options: nosniff`, `x-frame-options: DENY`, `referrer-policy`, `strict-transport-security`, `permissions-policy`, and a `content-security-policy` with `frame-ancestors 'none'`; no `x-powered-by` | [ ] |
| 5.5.8 | `curl -s https://YOUR-DOMAIN/api/health` | `{"ok":true,"database":"up",…}` with no secrets or error details | [ ] |
| 5.5.9 | `curl -i -X POST https://YOUR-DOMAIN/api/auth/logout` | `403` | [ ] |

### 5.6 Content safety

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 5.6.1 | Create a news article whose body contains `<script>alert(1)</script>` and `<img src=x onerror=alert(2)>`; publish and open it | The text is shown literally; nothing executes | [ ] |
| 5.6.2 | View the article's source and its JSON-LD | `<` characters are escaped inside the JSON-LD; the page is valid | [ ] |
| 5.6.3 | Submit a contact message beginning with `=HYPERLINK("http://evil.example")`; export or view it | Shown as text in Admin → Messages | [ ] |
| 5.6.4 | Register a member whose full name starts with `=` or `@`, then Export CSV and open it in a spreadsheet | The cell shows the text with a leading apostrophe and does not run as a formula | [ ] |
| 5.6.5 | Password recovery for an email that does not exist | The same "if an account exists" message is shown as for a real one | [ ] |
| 5.6.6 | Wrong password on `/login` | Generic "email or password is incorrect"; an `AUTH_FAILED_LOGIN` entry appears in the audit log | [ ] |

### 5.7 Password flows

| # | Action | Expected | ✔ |
| --- | --- | --- | --- |
| 5.7.1 | `/forgot-password` with MemberA's email | Success message; resend button counts down 60 seconds; reset email arrives | [ ] |
| 5.7.2 | Open the link, set a new password | "Password updated"; sent to `/login` with a notice; audit entries `AUTH_PASSWORD_RESET_REQUESTED` and `AUTH_PASSWORD_RESET` | [ ] |
| 5.7.3 | Open the same reset link a second time | "Link expired or invalid" | [ ] |
| 5.7.4 | `/member/settings` → Change password with a wrong current password | Field error; audit entry `AUTH_PASSWORD_CHANGE_FAILED` | [ ] |
| 5.7.5 | Change password correctly while signed in on two browsers | Succeeds; the other browser is signed out; audit entry `AUTH_PASSWORD_CHANGED` | [ ] |

---

## Part 6. Free-tier and operations check

- [ ] **Supabase → Reports/Usage:** database size, storage size and egress are far below the limits.
- [ ] **Supabase → Storage:** no file in `chapter-media` is larger than 250 KB (spot-check a few); no video files exist.
- [ ] **Vercel → Usage:** function invocations are normal; public pages are served from cache (static/ISR), not rendered on every visit.
- [ ] **EmailJS dashboard:** request count matches Admin → Settings (allow for emails sent outside this admin area).
- [ ] **Vercel → Cron Jobs:** the `/api/health` job ran and returned 200 at least once after deployment.
- [ ] A calendar reminder exists to export the database regularly and to review the audit log and usage monthly.
- [ ] At least two people can sign in as super administrator, so one lost password never locks the chapter out.

---

## Part 7. Sign-off

| Area | Tested by | Date | Result |
| --- | --- | --- | --- |
| Pre-launch checklist (Part 1) | | | Pass / Fail |
| Public site, SEO and GEO (Part 2) | | | Pass / Fail |
| Join, bootstrap and approval (Part 3) | | | Pass / Fail |
| Events, RSVP, attendance, alerts (Part 4) | | | Pass / Fail |
| Security boundaries (Part 5) | | | Pass / Fail |
| Free-tier and operations (Part 6) | | | Pass / Fail |

**Launch only when every Part 5 item passes and no Part 2, 3 or 4 item is left failing.** Record any known issue with its workaround here before launch:

> Known issues and workarounds: ______________________________________________
