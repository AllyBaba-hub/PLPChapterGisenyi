# PLP Chapter Gisenyi Digital Platform

The official website and member platform for **PLP Chapter Gisenyi**, the decentralized district chapter of **Peace and Love Proclaimers (PLP)** in **Gisenyi, Rubavu District, Rwanda**. PLP is a youth-led organization founded in Rwanda in 2007 that works for peacebuilding, unity, reconciliation and youth leadership.

The platform gives the chapter one home for everything it publishes and manages:

- a **public website** with chapter information, events, news, a photo and video gallery, online membership applications and a contact form;
- a **member portal** with a digital membership card, event registration, participation history, announcements, profile and account settings;
- an **admin suite** for reviewing applications, managing members and roles, publishing content, taking attendance, answering messages, printing reports and reviewing an audit trail.

It is built to run entirely on free tiers ($0 per month) and to be found by both search engines (SEO) and AI answer engines (GEO).

---

## Contents

1. [Tech stack and free-tier budget](#tech-stack-and-free-tier-budget)
2. [Architecture](#architecture)
3. [Project structure](#project-structure)
4. [Getting started](#getting-started)
5. [Database migrations (run in this order)](#database-migrations-run-in-this-order)
6. [Bootstrap the first super administrator](#bootstrap-the-first-super-administrator)
7. [Environment variables](#environment-variables)
8. [Supabase Auth configuration](#supabase-auth-configuration)
9. [EmailJS setup](#emailjs-setup)
10. [Deploying to Vercel](#deploying-to-vercel)
11. [Day-to-day operations](#day-to-day-operations)
12. [Security model](#security-model)
13. [Known limitations](#known-limitations)
14. [Troubleshooting](#troubleshooting)

---

## Tech stack and free-tier budget

| Layer | Choice | Free-tier notes |
| --- | --- | --- |
| Framework | Next.js 15 (App Router), React 19, TypeScript (strict) | |
| Styling | Tailwind CSS v3 with the plpyouth.org light-mode design tokens | Light theme only (`html[data-theme="light"]`) |
| Database, Auth, Storage | Supabase (PostgreSQL, Row-Level Security) | 500 MB database, 1 GB storage, 5 GB egress, 50,000 monthly active users. Projects pause after 7 days of inactivity, so a daily health check is included |
| Hosting | Vercel Hobby | Daily cron allowed; the project uses one |
| Email | EmailJS | 200 requests a month, 2 templates, 1 request a second |

Free-tier rules the code follows:

- **Videos are never stored.** The gallery stores YouTube links and embeds them with a click-to-load player.
- **Photos are compressed in the browser** to 250 KB or less before upload (the storage bucket also enforces a hard 512 KB cap).
- **Email is batched.** Activity alerts go out as BCC batches of up to 50 members, and the app stops before the monthly quota is used up.
- **Middleware only runs on `/member/*` and `/admin/*`,** so public pages stay fast, cacheable and cheap.

---

## Architecture

### Route groups

| Group | URLs | Access |
| --- | --- | --- |
| `app/(public)` | `/`, `/about`, `/events`, `/events/[id]`, `/news`, `/news/[id]`, `/gallery`, `/join`, `/contact` | Everyone. Statically cached for 5 minutes (ISR) |
| `app/(auth)` | `/login`, `/forgot-password`, `/reset-password` | Everyone, `noindex` |
| `app/(member)/member` | `/member`, `/member/card`, `/member/events`, `/member/history`, `/member/announcements`, `/member/profile`, `/member/settings` | Active members and above |
| `app/(admin)/admin` | `/admin`, `/admin/applications`, `/admin/members`, `/admin/events`, `/admin/news`, `/admin/gallery`, `/admin/announcements`, `/admin/messages`, `/admin/reports`, `/admin/settings`, `/admin/audit-logs` | Active admins and super admins |
| `app/api` | `/api/auth/*`, `/api/events/register`, `/api/members/export`, `/api/health` | Per route |

### Access control in three layers

1. **`middleware.ts`** protects `/member/*` and `/admin/*` (the matcher is deliberately limited to those two). It validates the Supabase session, reads the profile role and status, and redirects anonymous, pending, suspended or unauthorized users.
2. **Server guards** (`lib/rbac.ts`): `requireMember()` and `requireAdmin()` in layouts, and `authorizeApi()` in route handlers and server actions.
3. **PostgreSQL Row-Level Security and triggers** are the final authority. Even a forged request that bypasses the app cannot read or change data the database forbids.

Roles: `visitor < applicant < member < admin < super_admin`. Statuses: `pending`, `active`, `suspended`. Only `active` accounts with the right role get in. These rules mirror the SQL functions `is_active_member()` and `is_admin()`.

### Data flow

- **Public pages** read with a cookie-less Supabase client (`lib/supabase/public.ts`). Responses are cached for 5 minutes and tagged `public-data`; every admin change calls `revalidateTag("public-data")` and `revalidatePath(...)` so edits appear straight away.
- **Member and admin pages** read with the signed-in user's session, so RLS applies to every query.
- **Mutations** use server actions (`app/(member)/member/actions.ts`, `app/(admin)/admin/_actions/*.ts`) or route handlers. Each one authorizes the caller, validates and cleans the input, rate-limits, writes an audit entry through `services/audit.ts`, and revalidates caches.
- **Event registration** goes through database functions (`register_for_event`, `cancel_event_registration`) that lock the event row, so capacity can never be exceeded, even by simultaneous requests.
- **Audit logging** uses the service-role client (`lib/supabase/admin.ts`, server-only) so logs cannot be forged or skipped from the browser.
- **Email** is sent from the admin's browser through EmailJS (`lib/emailjs.ts`); each send is then recorded in the audit log, which is how monthly usage is counted.

### SEO and GEO

- `generateMetadata` on every public route (title, description, canonical URL, Open Graph, Twitter cards).
- `app/sitemap.ts` lists static pages plus every published event and news article. `app/robots.ts` allows public pages and blocks `/member/`, `/admin/` and `/api/`.
- JSON-LD (`lib/seo.ts`): `NGO` organization data on `/` and `/about`, `Event` on event pages, `NewsArticle` on article pages, plus `FAQPage`, `BreadcrumbList` and page types.
- `public/llms.txt` summarizes the chapter and its public routes for AI crawlers.
- Question-and-answer sections ("What is PLP Chapter Gisenyi?", "How to join Peace and Love Proclaimers in Gisenyi?") make the chapter easy to cite.

---

## Project structure

```text
plpchaptergisenyi/
├── app/
│   ├── layout.tsx, globals.css, error.tsx, not-found.tsx, sitemap.ts, robots.ts, icon.svg
│   ├── (public)/      Home, about, events, news, gallery, join, contact
│   ├── (auth)/        Login, forgot password, reset password
│   ├── (member)/      Member portal layout and pages, plus actions.ts (server actions)
│   ├── (admin)/       Admin layout and pages, plus _actions/ (server actions per area)
│   └── api/           auth/*, events/register, members/export, health
├── components/        admin/, auth/, layout/, member/, public/, seo/, ui/
├── lib/               rbac, supabase clients, validation, emailjs, seo, data helpers
├── services/audit.ts  recordAuditLog() and extractClientIp()
├── supabase/migrations/   Seven SQL files (see below)
├── public/            llms.txt, logo, social share image
├── middleware.ts      Protects /member/* and /admin/* only
├── next.config.ts     Security headers and image allow-list
├── vercel.json        Daily health-check cron
├── DEPLOYMENT_AND_QA.md   Launch checklist and manual QA script
└── .env.example
```

---

## Getting started

**Prerequisites:** Node.js 18.18 or newer (Node 20 recommended), npm, and free accounts at [Supabase](https://supabase.com), [Vercel](https://vercel.com) and [EmailJS](https://www.emailjs.com).

```bash
npm install
cp .env.example .env.local     # then fill in the values (see "Environment variables")
npm run dev                    # http://localhost:3000
```

Other scripts:

| Command | What it does |
| --- | --- |
| `npm run dev` | Development server |
| `npm run build` | Production build (also type-checks and lints) |
| `npm run start` | Serve the production build |
| `npm run lint` | ESLint (Next.js core-web-vitals rules) |
| `npm run typecheck` | TypeScript check. Run `npm run dev` or `npm run build` once first so `next-env.d.ts` exists |

Setup order for a brand-new environment: create the Supabase project, run the migrations, bootstrap the super administrator, fill in the environment variables, configure Supabase Auth URLs, then set up EmailJS.

---

## Database migrations (run in this order)

Create a Supabase project, then run the files in `supabase/migrations/` **in timestamp order, each exactly once**. The simplest way is the dashboard: **SQL Editor → New query**, paste a file, **Run**, then move to the next.

| Order | File | What it does |
| --- | --- | --- |
| 1 | `20260908120100_core_tables.sql` | Enums, all core tables (profiles, applications, events, registrations, news, gallery, messages, audit logs), indexes and `updated_at` triggers |
| 2 | `20260908120300_rbac_functions.sql` | Member ID generator (`PLP-GIS-YYYY-0001`), `is_admin()` and related role functions, profile creation on sign-up, the atomic `approve_membership_application()` function |
| 3 | `20260908120400_rls_policies.sql` | Row-Level Security policies for the core tables |
| 4 | `20260908120500_storage.sql` | The public `chapter-media` bucket (512 KB cap, JPEG/PNG/WebP only) and its storage policies |
| 5 | `20260908120600_announcements_and_settings.sql` | Announcements, read tracking and the single `chapter_settings` row |
| 6 | `20260908120700_member_portal.sql` | Protected profile fields, capacity-safe `register_for_event()` and `cancel_event_registration()`, registration counts |
| 7 | `20260908120800_admin_suite.sql` | Role-hierarchy trigger, protected participation history, admin indexes |

Notes:

- The timestamp gap at `…120200` is intentional; there is no such file.
- Order matters: later files rely on functions and tables from earlier ones.
- The files are not safe to re-run (policies are created without `IF NOT EXISTS`). To start over, reset the database or drop the objects first.
- **Using the Supabase CLI instead:** `npx supabase init` (keep the existing `supabase/migrations` folder), `npx supabase login`, `npx supabase link --project-ref YOUR_PROJECT_REF`, then `npx supabase db push`.
- After running them all, use the verification queries in [`DEPLOYMENT_AND_QA.md`](./DEPLOYMENT_AND_QA.md) to confirm RLS, triggers and storage are in place.

---

## Bootstrap the first super administrator

Nobody can promote themselves, so the very first super administrator is created directly in the database. The SQL editor runs without a signed-in user (`auth.uid()` is null), which is exactly what the role-hierarchy trigger allows for this one-time step.

1. In the Supabase dashboard open **Authentication → Users → Add user → Create new user**. Enter the future administrator's email and a strong password, and tick **Auto Confirm User**. (Alternatively, apply through `/join`, confirm the email, and continue below.)
2. The sign-up automatically creates a `profiles` row with role `applicant` and status `pending`.
3. In **SQL Editor** run (replace the email with the one from step 1):

   ```sql
   UPDATE public.profiles
   SET role = 'super_admin',
       status = 'active',
       member_code = COALESCE(member_code, public.generate_member_code()),
       joined_at = COALESCE(joined_at, NOW())
   WHERE email = 'first.admin@example.org';
   ```

4. Confirm exactly one row was updated:

   ```sql
   SELECT email, role, status, member_code FROM public.profiles WHERE role = 'super_admin';
   ```

5. Sign in at `/login`. You land on `/admin`.

From then on, manage everyone from **Admin → Members**: only super administrators can create or change other administrators, nobody can change their own role or status, and the last active super administrator can never be demoted or suspended.

---

## Environment variables

Copy `.env.example` to `.env.local` for local work, and add the same values in **Vercel → Project Settings → Environment Variables**. `NEXT_PUBLIC_*` values are inlined at build time, so **redeploy after changing any of them**.

| Variable | Where to find it | Notes |
| --- | --- | --- |
| `NEXT_PUBLIC_SITE_URL` | Your public address, e.g. `https://plpgisenyi.example.org` | No trailing slash. Used for canonical URLs, the sitemap, Open Graph and JSON-LD |
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase → Project Settings → API → Project URL | |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase → Project Settings → API → `anon` `public` key | Safe for the browser; RLS protects the data |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase → Project Settings → API → `service_role` key | **Secret. Server only.** Bypasses RLS. Never prefix with `NEXT_PUBLIC_` and never commit it |
| `NEXT_PUBLIC_EMAILJS_SERVICE_ID` | EmailJS → Email Services | |
| `NEXT_PUBLIC_EMAILJS_PUBLIC_KEY` | EmailJS → Account → API keys → Public key | |
| `NEXT_PUBLIC_EMAILJS_ACTIVITY_TEMPLATE_ID` | EmailJS → Email Templates (Template 1) | Activity and announcement alerts |
| `NEXT_PUBLIC_EMAILJS_ACCOUNT_TEMPLATE_ID` | EmailJS → Email Templates (Template 2) | Approval and account status notices |

---

## Supabase Auth configuration

In the Supabase dashboard (menu names can shift slightly as the dashboard evolves):

1. **Authentication → URL Configuration**
   - **Site URL:** your production address (the same as `NEXT_PUBLIC_SITE_URL`).
   - **Redirect URLs:** add all of these (use your real domain; keep the `localhost` entries for development):
     - `https://YOUR-DOMAIN/reset-password` (password recovery emails land here)
     - `https://YOUR-DOMAIN/login` (email-confirmation links land here)
     - `http://localhost:3000/reset-password`
     - `http://localhost:3000/login`
2. **Authentication → Providers → Email**
   - Keep **Confirm email** switched on (recommended). The join form handles both cases.
   - Set the **minimum password length to 8** to match the forms.
3. **Authentication → SMTP Settings:** configure a custom SMTP provider before launch. Supabase's built-in sender allows only a few emails an hour, which is not enough for sign-up confirmations and password resets.
4. **Authentication → Email Templates (optional):** brand the confirmation and recovery emails with the chapter name.

The storage bucket `chapter-media` is created by migration 4; there is nothing to configure by hand.

---

## EmailJS setup

The free plan allows **2 templates**, which is why the platform uses exactly two.

1. In EmailJS, **add an email service** (for example Gmail) and note its **Service ID**.
2. Copy your **Public Key** (Account → API keys).
3. Create **Template 1: Chapter activity / announcement alert** (note its Template ID):
   - **To email:** `{{to_email}}`  ·  **Bcc:** `{{bcc}}`  ·  **Reply-to:** `{{reply_to}}`
   - **Subject:** `{{subject}}`  ·  **From name:** `{{chapter_name}}`
   - **Body:**

     ```html
     <div style="font-family: Arial, sans-serif; max-width: 560px; margin: 0 auto; color: #0f1729;">
       <p style="margin: 0 0 8px; color: #1d77dd; font-weight: bold;">{{priority_label}}</p>
       <h2 style="margin: 0 0 12px;">{{title}}</h2>
       <p style="white-space: pre-line;">{{message}}</p>
       <p><strong>When:</strong> {{event_date}}<br><strong>Where:</strong> {{event_location}}</p>
       <p>
         <a href="{{action_url}}" style="background: #1d77dd; color: #ffffff; padding: 10px 18px; border-radius: 8px; text-decoration: none; display: inline-block;">{{action_label}}</a>
       </p>
       <hr style="border: none; border-top: 1px solid #dbe4f0; margin: 24px 0;">
       <p style="font-size: 12px; color: #64748b;">You receive this because you are an active member of {{chapter_name}}. You can switch off email alerts under Member portal → Settings.</p>
     </div>
     ```

     Announcements have no event date or place, so those two lines render blank. Delete the "When/Where" line from the template if you mostly send announcements.
4. Create **Template 2: Membership approval / account status notice**:
   - **To email:** `{{to_email}}`  ·  **Reply-to:** `{{reply_to}}`
   - **Subject:** `{{subject}}`  ·  **From name:** `{{chapter_name}}`
   - **Body:**

     ```html
     <div style="font-family: Arial, sans-serif; max-width: 560px; margin: 0 auto; color: #0f1729;">
       <h2 style="margin: 0 0 12px;">{{heading}}</h2>
       <p>{{message}}</p>
       <p style="white-space: pre-line;">{{details}}</p>
       <p><strong>Member ID:</strong> {{member_code}}</p>
       <p>
         <a href="{{action_url}}" style="background: #1d77dd; color: #ffffff; padding: 10px 18px; border-radius: 8px; text-decoration: none; display: inline-block;">{{action_label}}</a>
       </p>
       <hr style="border: none; border-top: 1px solid #dbe4f0; margin: 24px 0;">
       <p style="font-size: 12px; color: #64748b;">{{chapter_name}}</p>
     </div>
     ```

     Member ID and details are empty for some notices (for example a rejection), so they simply render blank.
5. Put the four IDs and the public key into the environment variables above.
6. In EmailJS **Account → Security**, restrict the allowed origins to your production domain if your plan offers it.

Variable reference (these exact names are sent by `lib/emailjs.ts`):

| Template | Variables |
| --- | --- |
| 1 (activity) | `to_email`, `bcc`, `reply_to`, `subject`, `title`, `message`, `priority_label`, `event_date`, `event_location`, `action_url`, `action_label`, `chapter_name` |
| 2 (account) | `to_email`, `to_name`, `reply_to`, `subject`, `heading`, `message`, `details`, `member_code`, `action_url`, `action_label`, `chapter_name` |

How the quota is protected: requests are queued at least 1.1 seconds apart, one retry follows a rate-limit response, activity alerts stop at 180 requests a month and account notices at 195, and a whole batch is checked against the remaining budget before anything is sent. Usage is counted from the audit log (Admin → Settings and Admin → Reports); the EmailJS dashboard remains the source of truth. The number of BCC recipients per request is capped at 50, a conservative value: confirm your email service accepts that many.

---

## Deploying to Vercel

1. Push the repository to GitHub (never commit `.env.local`; `.gitignore` already excludes it).
2. In Vercel choose **Add New → Project**, import the repository, and keep the detected **Next.js** preset.
3. Add all eight environment variables for **Production** (and Preview if you use preview deployments).
4. Deploy, then attach your domain under **Settings → Domains**.
5. Update **Supabase Site URL and Redirect URLs** to the final domain, and make sure `NEXT_PUBLIC_SITE_URL` matches it. Redeploy if you changed it.
6. Check **Settings → Cron Jobs**: the daily `/api/health` job from `vercel.json` should be listed. It keeps the free Supabase project from pausing after 7 days of inactivity.

Then work through [`DEPLOYMENT_AND_QA.md`](./DEPLOYMENT_AND_QA.md) before announcing the site.

---

## Day-to-day operations

| Task | Where |
| --- | --- |
| Review a new application | Admin → Applications → Review. Approving assigns a member ID, upgrades the account, and can email the applicant |
| Suspend or reactivate a member | Admin → Members → Manage |
| Promote someone to administrator | Admin → Members → Manage (super administrators only) |
| Publish an event and alert members | Admin → Events → New event, then **Email members about this** (check the recipient count and quota first) |
| Record attendance | Admin → Events → Registrations |
| Post a notice for members | Admin → Announcements |
| Answer a contact message | Admin → Messages → Reply by email, then mark it replied |
| Change chapter details, social links, or close applications | Admin → Settings |
| Print or save a summary for leadership | Admin → Reports → Print or save as PDF |
| Investigate who did what | Admin → Audit logs |
| Export the member roster | Admin → Members → Export CSV |

Monthly: watch Supabase database and storage usage and the Vercel and EmailJS dashboards. Free projects have no point-in-time recovery, so schedule a periodic database export (`pg_dump` or the dashboard's backup tools) and keep it somewhere safe.

---

## Security model

- Route protection in middleware, server guards and database RLS (three independent layers).
- Roles and status are enforced in the database: members cannot change `role`, `status`, `member_code`, `email` or `joined_at`; nobody can change their own role or status; only super administrators manage administrator accounts; the last super administrator cannot be removed.
- Capacity and participation integrity: registrations only through locked database functions; members cannot delete registration rows; cancelling is refused once an event has started.
- Every server mutation is authorized, validated, rate-limited, audit-logged and cache-revalidated.
- Same-origin checks on state-changing endpoints, safe `?next=` redirects (internal paths only), no account enumeration on login or password reset.
- CMS text is rendered as plain text (no HTML injection); JSON-LD is escaped; CSV exports neutralize spreadsheet formulas.
- The service-role key is only used in server-only modules and never reaches the browser.
- Security headers are set in `next.config.ts` (`nosniff`, frame blocking, HSTS, referrer and permissions policies).

---

## Known limitations

- **Rate limiting is per server instance.** On serverless hosting it blunts bursts and abuse but is not a global guarantee. Supabase Auth has its own limits on top.
- **Email is sent from the admin's browser,** so an admin needs a working connection while sending. EmailJS usage is counted only for emails sent through this admin area.
- **Applications cannot be deleted** in the admin area (the database policies do not allow it). Reject them instead.
- **The membership QR code encodes the member ID only.** There is no public verification page, to avoid exposing member data. Admins can look members up by ID in Admin → Members.
- **Photos use plain `<img>` tags.** `next.config.ts` already allows `*.supabase.co` storage URLs, so switching to `next/image` later is straightforward.
- **Reports** read up to 20,000 registrations; far beyond a single chapter's needs on the free tier.

---

## Troubleshooting

| Symptom | Likely cause and fix |
| --- | --- |
| Password reset link says "expired or invalid" | The Redirect URL `https://YOUR-DOMAIN/reset-password` is not in Supabase Auth settings, or the link was opened in a different browser than the one used to request it |
| Sign-up confirmation email never arrives | Supabase's built-in email limit; set up custom SMTP |
| Signed in but sent to "Join" with a pending notice | The account is still `pending`. Approve the application, or bootstrap the account as described above |
| `/admin` redirects to `/member?error=forbidden` | The account is a member, not an admin |
| Pages show old data after an edit | Edits revalidate caches automatically; if you edited the database directly, wait up to 5 minutes or redeploy |
| Site shows default chapter text and empty lists | Supabase environment variables missing or wrong, or migrations not run. Check the Vercel build log and `/api/health` |
| Event registration says it could not be updated | Migration 6 (`…120700`) has not been run |
| Admin role change says "Only a super administrator…" | Expected for regular administrators; ask a super administrator |
| Email alerts do nothing | EmailJS variables missing (Admin → Settings shows "Not configured"), template IDs wrong, or the monthly budget is used up |
| Photo upload fails | The file is not JPEG, PNG or WebP, or you are not signed in with an account allowed to upload to that folder |
| `npm run typecheck` complains about `globals.css` on a fresh clone | Run `npm run dev` or `npm run build` once to generate `next-env.d.ts` |
