import Link from "next/link";
import { EventRegisterButton } from "@/components/member/EventRegisterButton";
import { CoverImage } from "@/components/public/CoverImage";
import { Badge } from "@/components/ui/Badge";
import type { EventWithRsvp } from "@/lib/member-data";
import { cn, formatEventWhen, getDateParts, truncate } from "@/lib/utils";

export function MemberEventCard({ event, past = false }: { event: EventWithRsvp; past?: boolean }) {
  const parts = getDateParts(event.start_time);
  const capacity = event.max_capacity;
  const percent = capacity ? Math.min(100, Math.round((event.registered_count / capacity) * 100)) : 0;
  const spotsLeft = capacity ? Math.max(0, capacity - event.registered_count) : null;

  return (
    <article className="flex h-full flex-col overflow-hidden rounded-xl border bg-card text-card-foreground shadow-sm">
      <CoverImage src={event.cover_image_url} alt={`Cover image for ${event.title}`} className="aspect-[16/9] w-full" />

      <div className="flex flex-1 flex-col gap-4 p-5">
        <div className="flex gap-4">
          <div
            aria-hidden="true"
            className={cn(
              "flex h-14 w-14 shrink-0 flex-col items-center justify-center rounded-lg text-center",
              past ? "bg-secondary text-muted-foreground" : "bg-accent text-accent-foreground"
            )}
          >
            <span className="text-lg font-bold leading-none">{parts.day}</span>
            <span className="mt-0.5 text-xs font-medium uppercase">{parts.month}</span>
          </div>
          <div className="min-w-0">
            <h3 className="text-lg sm:text-lg">
              <Link href={`/events/${event.slug}`} className="hover:underline">
                {event.title}
              </Link>
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">{formatEventWhen(event.start_time, event.end_time)}</p>
            <p className="text-sm text-muted-foreground">{event.location}</p>
          </div>
        </div>

        <p className="text-sm leading-6">{truncate(event.summary, 140)}</p>

        <div className="mt-auto space-y-3">
          <div>
            <p className="text-xs font-medium text-muted-foreground">
              {capacity
                ? `${event.registered_count} of ${capacity} places taken${
                    !past && spotsLeft !== null ? ` · ${spotsLeft} left` : ""
                  }`
                : `${event.registered_count} registered`}
            </p>
            {capacity ? (
              <div aria-hidden="true" className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-secondary">
                <div
                  className={cn("h-full rounded-full", event.is_full ? "bg-destructive" : "bg-primary")}
                  style={{ width: `${percent}%` }}
                />
              </div>
            ) : null}
          </div>

          {past ? (
            event.is_registered ? (
              <Badge tone={event.attended ? "success" : "muted"}>
                {event.attended ? "You attended" : "You were registered"}
              </Badge>
            ) : null
          ) : (
            <div className="flex flex-wrap items-center gap-3">
              {event.is_registered ? <Badge tone="success">You&apos;re registered</Badge> : null}
              <EventRegisterButton
                eventId={event.id}
                eventTitle={event.title}
                registered={event.is_registered}
                full={event.is_full}
              />
            </div>
          )}
        </div>
      </div>
    </article>
  );
}
