import { cn } from "@/lib/utils";

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  const first = parts[0].charAt(0);
  const last = parts.length > 1 ? parts[parts.length - 1].charAt(0) : "";
  return `${first}${last}`.toUpperCase();
}

interface UserAvatarProps {
  name: string;
  src?: string | null;
  size?: number;
  className?: string;
}

export function UserAvatar({ name, src, size = 40, className }: UserAvatarProps) {
  const style = { width: size, height: size, fontSize: Math.max(12, Math.round(size * 0.38)) };

  if (src) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={src}
        alt={`Profile photo of ${name}`}
        width={size}
        height={size}
        loading="lazy"
        decoding="async"
        style={{ width: size, height: size }}
        className={cn("shrink-0 rounded-full border object-cover", className)}
      />
    );
  }

  return (
    <span
      role="img"
      aria-label={`Avatar for ${name}`}
      style={style}
      className={cn(
        "inline-flex shrink-0 items-center justify-center rounded-full bg-accent font-semibold text-accent-foreground",
        className
      )}
    >
      {initials(name)}
    </span>
  );
}
