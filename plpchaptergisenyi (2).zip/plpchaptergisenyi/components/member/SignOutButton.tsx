import { Icon } from "@/components/member/icons";
import { cn } from "@/lib/utils";

/** Plain form POST to /api/auth/logout; the route clears the session and redirects to /login. */
export function SignOutButton({ className, label = "Sign out" }: { className?: string; label?: string }) {
  return (
    <form action="/api/auth/logout" method="post">
      <button
        type="submit"
        className={cn(
          "inline-flex h-10 items-center justify-center gap-2 rounded-md border border-input bg-background px-3 text-sm font-semibold text-foreground transition-colors hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
          className
        )}
      >
        <Icon name="logout" className="h-4 w-4" />
        {label}
      </button>
    </form>
  );
}
