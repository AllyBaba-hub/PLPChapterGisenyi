"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { removeAvatar, setAvatar } from "@/app/(member)/member/actions";
import { AuthAlert, Spinner } from "@/components/auth/ui";
import { UserAvatar } from "@/components/member/UserAvatar";
import { buttonClass } from "@/components/ui/styles";
import { compressImage, ImageCompressionError, validateImageFile } from "@/lib/image-compress";
import { createClient } from "@/lib/supabase/client";
import { MAX_UPLOAD_BYTES, MEDIA_BUCKET, newAvatarPath } from "@/lib/storage";

interface AvatarUploaderProps {
  userId: string;
  fullName: string;
  avatarUrl: string | null;
}

type Step = "idle" | "compressing" | "uploading" | "removing";

export function AvatarUploader({ userId, fullName, avatarUrl }: AvatarUploaderProps) {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [step, setStep] = useState<Step>("idle");
  const [preview, setPreview] = useState<string | null>(null);
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);

  useEffect(() => {
    return () => {
      if (preview) URL.revokeObjectURL(preview);
    };
  }, [preview]);

  const busy = step !== "idle";
  const shownUrl = preview ?? avatarUrl;

  async function handleFile(file: File) {
    setNotice(null);

    const problem = validateImageFile(file);
    if (problem) {
      setNotice({ tone: "error", text: problem });
      return;
    }

    try {
      setStep("compressing");
      const compressed = await compressImage(file, {
        maxDimension: 512,
        maxBytes: MAX_UPLOAD_BYTES,
        square: true,
      });

      setPreview(URL.createObjectURL(compressed.blob));
      setStep("uploading");

      const supabase = createClient();
      const path = newAvatarPath(userId, compressed.extension);
      const { error: uploadError } = await supabase.storage.from(MEDIA_BUCKET).upload(path, compressed.blob, {
        contentType: compressed.blob.type,
        cacheControl: "31536000",
        upsert: false,
      });

      if (uploadError) {
        setPreview(null);
        setNotice({ tone: "error", text: "We couldn't upload your photo. Please try again." });
        return;
      }

      const result = await setAvatar(path);
      if (!result.ok) {
        await supabase.storage.from(MEDIA_BUCKET).remove([path]);
        setPreview(null);
        setNotice({ tone: "error", text: result.error });
        return;
      }

      setNotice({ tone: "success", text: result.message ?? "Your profile photo was updated." });
      router.refresh();
    } catch (error) {
      setPreview(null);
      setNotice({
        tone: "error",
        text: error instanceof ImageCompressionError ? error.message : "Something went wrong while uploading your photo.",
      });
    } finally {
      setStep("idle");
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  async function handleRemove() {
    setNotice(null);
    setStep("removing");
    const result = await removeAvatar();
    setStep("idle");
    if (!result.ok) {
      setNotice({ tone: "error", text: result.error });
      return;
    }
    setPreview(null);
    setNotice({ tone: "success", text: result.message ?? "Your profile photo was removed." });
    router.refresh();
  }

  return (
    <div>
      <div className="flex flex-wrap items-center gap-5">
        <UserAvatar name={fullName} src={shownUrl} size={88} />
        <div className="space-y-2">
          <div className="flex flex-wrap gap-2">
            <input
              ref={inputRef}
              id="avatar-file"
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="sr-only"
              disabled={busy}
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (file) void handleFile(file);
              }}
            />
            <label
              htmlFor="avatar-file"
              className={`${buttonClass("outline")} cursor-pointer ${busy ? "pointer-events-none opacity-60" : ""}`}
            >
              {busy && step !== "removing" ? <Spinner /> : null}
              {step === "compressing" ? "Preparing…" : step === "uploading" ? "Uploading…" : avatarUrl ? "Change photo" : "Upload photo"}
            </label>
            {avatarUrl ? (
              <button type="button" onClick={handleRemove} disabled={busy} className={buttonClass("ghost")}>
                {step === "removing" ? <Spinner /> : null}
                Remove
              </button>
            ) : null}
          </div>
          <p className="text-xs text-muted-foreground">
            JPEG, PNG or WebP. Photos are cropped to a square and compressed to under 250 KB automatically.
          </p>
        </div>
      </div>

      {notice ? (
        <div className="mt-4">
          <AuthAlert variant={notice.tone === "error" ? "error" : "success"}>{notice.text}</AuthAlert>
        </div>
      ) : null}
    </div>
  );
}
