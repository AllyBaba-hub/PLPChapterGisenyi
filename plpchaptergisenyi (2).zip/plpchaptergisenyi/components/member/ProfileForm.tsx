"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { updateProfile } from "@/app/(member)/member/actions";
import { AuthAlert, inputClass, primaryButtonClass, Spinner } from "@/components/auth/ui";
import { describedBy, Field } from "@/components/public/FormField";
import { textareaClass } from "@/components/ui/styles";

interface ProfileFormProps {
  email: string;
  initial: {
    full_name: string;
    phone: string;
    sector_or_cell: string;
    school_or_occupation: string;
    bio: string;
  };
}

type Values = ProfileFormProps["initial"];

export function ProfileForm({ email, initial }: ProfileFormProps) {
  const router = useRouter();
  const [values, setValues] = useState<Values>(initial);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);
  const [saving, setSaving] = useState(false);

  function update<K extends keyof Values>(key: K, value: Values[K]) {
    setValues((current) => ({ ...current, [key]: value }));
    setErrors((current) => {
      if (!current[key]) return current;
      const { [key]: _removed, ...rest } = current;
      void _removed;
      return rest;
    });
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (saving) return;
    setNotice(null);
    setSaving(true);

    try {
      const result = await updateProfile(values);
      if (result.ok) {
        setErrors({});
        setNotice({ tone: "success", text: result.message ?? "Your profile was saved." });
        router.refresh();
      } else {
        setErrors(result.fieldErrors ?? {});
        setNotice({ tone: "error", text: result.error });
        const first = Object.keys(result.fieldErrors ?? {})[0];
        if (first) document.getElementById(`profile-${first}`)?.focus();
      }
    } catch {
      setNotice({ tone: "error", text: "We couldn't reach the server. Check your connection and try again." });
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} noValidate aria-busy={saving} className="space-y-5">
      {notice ? <AuthAlert variant={notice.tone === "error" ? "error" : "success"}>{notice.text}</AuthAlert> : null}

      <Field id="profile-full_name" label="Full name" required error={errors.full_name}>
        <input
          id="profile-full_name"
          type="text"
          autoComplete="name"
          maxLength={120}
          value={values.full_name}
          onChange={(e) => update("full_name", e.target.value)}
          aria-invalid={Boolean(errors.full_name)}
          aria-describedby={describedBy("profile-full_name", errors.full_name)}
          className={inputClass}
        />
      </Field>

      <div>
        <label htmlFor="profile-email" className="mb-1.5 block text-sm font-medium text-foreground">
          Email address
        </label>
        <input id="profile-email" type="email" value={email} readOnly disabled className={inputClass} />
        <p className="mt-1.5 text-xs text-muted-foreground">
          Your email is your sign-in name and can&apos;t be changed here. Contact the chapter if it needs updating.
        </p>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field id="profile-phone" label="Phone number" error={errors.phone}>
          <input
            id="profile-phone"
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            maxLength={20}
            value={values.phone}
            onChange={(e) => update("phone", e.target.value)}
            aria-invalid={Boolean(errors.phone)}
            aria-describedby={describedBy("profile-phone", errors.phone)}
            className={inputClass}
          />
        </Field>
        <Field id="profile-sector_or_cell" label="Sector or cell" error={errors.sector_or_cell}>
          <input
            id="profile-sector_or_cell"
            type="text"
            maxLength={120}
            value={values.sector_or_cell}
            onChange={(e) => update("sector_or_cell", e.target.value)}
            className={inputClass}
          />
        </Field>
      </div>

      <Field id="profile-school_or_occupation" label="School or occupation">
        <input
          id="profile-school_or_occupation"
          type="text"
          maxLength={160}
          value={values.school_or_occupation}
          onChange={(e) => update("school_or_occupation", e.target.value)}
          className={inputClass}
        />
      </Field>

      <Field id="profile-bio" label="About you" hint={`${values.bio.length}/500 characters`} error={errors.bio}>
        <textarea
          id="profile-bio"
          maxLength={500}
          value={values.bio}
          onChange={(e) => update("bio", e.target.value)}
          aria-describedby={describedBy("profile-bio", errors.bio, "hint")}
          className={textareaClass}
        />
      </Field>

      <button type="submit" disabled={saving} className={primaryButtonClass}>
        {saving ? (
          <>
            <Spinner />
            Saving…
          </>
        ) : (
          "Save profile"
        )}
      </button>
    </form>
  );
}
