"use client";

import { Spinner } from "@/components/auth/ui";

interface AnnouncementReadToggleProps {
  isRead: boolean;
  pending: boolean;
  onToggle: () => void;
  title: string;
}

export function AnnouncementReadToggle({ isRead, pending, onToggle, title }: AnnouncementReadToggleProps) {
  return (
    <button
      type="button"
      onClick={onToggle}
      disabled={pending}
      aria-label={isRead ? `Mark "${title}" as unread` : `Mark "${title}" as read`}
      className="inline-flex h-8 items-center gap-2 rounded-md border border-input bg-background px-3 text-xs font-semibold text-foreground transition-colors hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-60"
    >
      {pending ? <Spinner className="h-3 w-3" /> : null}
      {isRead ? "Mark as unread" : "Mark as read"}
    </button>
  );
}
