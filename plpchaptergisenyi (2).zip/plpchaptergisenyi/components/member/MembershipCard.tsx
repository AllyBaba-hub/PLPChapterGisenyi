import { BrandMark } from "@/components/layout/BrandLogo";
import { UserAvatar } from "@/components/member/UserAvatar";
import { Badge } from "@/components/ui/Badge";
import { ROLE_LABELS, STATUS_LABELS } from "@/lib/labels";
import type { Profile } from "@/lib/rbac";
import { formatDate } from "@/lib/utils";

interface MembershipCardProps {
  profile: Profile;
  chapterName: string;
  parentOrganization: string;
  /** Trusted SVG markup generated server-side by the qrcode library. */
  qrSvg: string | null;
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <dt className="text-[0.7rem] font-semibold uppercase tracking-wide text-muted-foreground">{label}</dt>
      <dd className="truncate text-sm font-medium text-foreground">{value}</dd>
    </div>
  );
}

export function MembershipCard({ profile, chapterName, parentOrganization, qrSvg }: MembershipCardProps) {
  const statusTone = profile.status === "active" ? "success" : profile.status === "pending" ? "warning" : "danger";

  return (
    <div className="grid gap-6 lg:grid-cols-2 print:grid-cols-2 print:gap-4">
      {/* Front */}
      <section
        aria-label="Membership card, front"
        className="break-inside-avoid overflow-hidden rounded-2xl border bg-card text-card-foreground shadow-md"
      >
        <div className="flex items-center justify-between gap-3 bg-primary px-5 py-3 text-primary-foreground">
          <div className="flex items-center gap-3">
            <BrandMark size={34} />
            <div className="leading-tight">
              <p className="text-sm font-bold">{chapterName}</p>
              <p className="text-xs text-primary-foreground/85">Official membership card</p>
            </div>
          </div>
        </div>

        <div className="flex gap-5 p-5">
          <UserAvatar name={profile.full_name} src={profile.avatar_url} size={96} className="rounded-xl" />
          <div className="min-w-0 flex-1">
            <p className="truncate text-xl font-bold tracking-tight">{profile.full_name}</p>
            <p className="mt-0.5 text-sm text-muted-foreground">{ROLE_LABELS[profile.role]}</p>
            <div className="mt-2">
              <Badge tone={statusTone}>{STATUS_LABELS[profile.status]}</Badge>
            </div>
          </div>
        </div>

        <div className="border-t bg-secondary/60 px-5 py-4">
          <p className="text-[0.7rem] font-semibold uppercase tracking-wide text-muted-foreground">Member ID</p>
          <p className="font-mono text-2xl font-bold tracking-wider text-foreground">
            {profile.member_code ?? "Not yet assigned"}
          </p>
          <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3">
            <Detail label="Sector / cell" value={profile.sector_or_cell ?? "Not provided"} />
            <Detail label="Member since" value={profile.joined_at ? formatDate(profile.joined_at) : "Not recorded"} />
          </dl>
        </div>
      </section>

      {/* Back */}
      <section
        aria-label="Membership card, back"
        className="flex break-inside-avoid flex-col overflow-hidden rounded-2xl border bg-card text-card-foreground shadow-md"
      >
        <div className="bg-primary px-5 py-3 text-primary-foreground">
          <p className="text-sm font-bold">Verification</p>
          <p className="text-xs text-primary-foreground/85">Scan or read the code to confirm this membership</p>
        </div>

        <div className="flex flex-1 flex-col items-center justify-center gap-4 p-6">
          {qrSvg ? (
            <div
              role="img"
              aria-label={`QR code for member ID ${profile.member_code}`}
              className="h-44 w-44 rounded-lg border bg-white p-2 [&>svg]:h-full [&>svg]:w-full"
              dangerouslySetInnerHTML={{ __html: qrSvg }}
            />
          ) : (
            <p className="rounded-lg border bg-secondary p-6 text-center text-sm text-muted-foreground">
              Your verification code appears here once a member ID is assigned.
            </p>
          )}
          <p className="font-mono text-lg font-bold tracking-wider">{profile.member_code ?? "—"}</p>
        </div>

        <p className="border-t bg-secondary/60 px-5 py-3 text-xs leading-5 text-muted-foreground">
          Issued by {chapterName}, a chapter of {parentOrganization}. Valid while the membership status is
          Active. If found, please contact the chapter.
        </p>
      </section>
    </div>
  );
}
