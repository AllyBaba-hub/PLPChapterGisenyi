"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { buttonClass } from "@/components/ui/styles";
import { Spinner } from "@/components/auth/ui";

interface EventRegisterButtonProps {
  eventId: string;
  eventTitle: string;
  registered: boolean;
  full: boolean;
}

export function EventRegisterButton({ eventId, eventTitle, registered, full }: EventRegisterButtonProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState<{ tone: "error" | "success"; text: string } | null>(null);

  const busy = submitting || isPending;

  async function submit(action: "register" | "unregister") {
    if (busy) return;
    setSubmitting(true);
    setMessage(null);

    try {
      const response = await fetch("/api/events/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ event_id: eventId, action }),
      });
      const result = (await response.json().catch(() => null)) as { ok?: boolean; message?: string; error?: string } | null;

      if (response.ok && result?.ok) {
        setMessage({ tone: "success", text: result.message ?? "Saved." });
        startTransition(() => router.refresh());
      } else {
        setMessage({
          tone: "error",
          text: result?.message ?? result?.error ?? "We couldn't update your registration. Please try again.",
        });
        if (response.status === 409) startTransition(() => router.refresh());
      }
    } catch {
      setMessage({ tone: "error", text: "We couldn't reach the server. Check your connection and try again." });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex flex-col items-start gap-2">
      {registered ? (
        <button
          type="button"
          onClick={() => submit("unregister")}
          disabled={busy}
          aria-label={`Cancel registration for ${eventTitle}`}
          className={buttonClass("outline")}
        >
          {busy ? <Spinner /> : null}
          Cancel registration
        </button>
      ) : full ? (
        <button type="button" disabled className={buttonClass("outline")}>
          Event full
        </button>
      ) : (
        <button
          type="button"
          onClick={() => submit("register")}
          disabled={busy}
          aria-label={`Register for ${eventTitle}`}
          className={buttonClass("primary")}
        >
          {busy ? <Spinner /> : null}
          Register
        </button>
      )}
      {message ? (
        <p
          role={message.tone === "error" ? "alert" : "status"}
          className={message.tone === "error" ? "text-xs font-medium text-destructive" : "text-xs font-medium text-foreground"}
        >
          {message.text}
        </p>
      ) : null}
    </div>
  );
}
