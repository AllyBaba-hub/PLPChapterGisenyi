"use client";

import { useState } from "react";
import { setEmailNotifications } from "@/app/(member)/member/actions";
import { cn } from "@/lib/utils";

export function EmailPreferenceToggle({ initialEnabled }: { initialEnabled: boolean }) {
  const [enabled, setEnabled] = useState(initialEnabled);
  const [pending, setPending] = useState(false);
  const [message, setMessage] = useState<{ tone: "success" | "error"; text: string } | null>(null);

  async function toggle() {
    if (pending) return;
    const next = !enabled;
    setEnabled(next);
    setPending(true);
    setMessage(null);

    try {
      const result = await setEmailNotifications(next);
      if (result.ok) {
        setMessage({ tone: "success", text: result.message ?? "Saved." });
      } else {
        setEnabled(!next);
        setMessage({ tone: "error", text: result.error });
      }
    } catch {
      setEnabled(!next);
      setMessage({ tone: "error", text: "We couldn't reach the server. Please try again." });
    } finally {
      setPending(false);
    }
  }

  return (
    <div>
      <div className="flex items-start justify-between gap-4">
        <div>
          <p id="email-pref-label" className="text-sm font-semibold">
            Chapter email alerts
          </p>
          <p id="email-pref-desc" className="mt-1 text-sm text-muted-foreground">
            Get an email when the chapter announces new activities or important updates.
          </p>
        </div>
        <button
          type="button"
          role="switch"
          aria-checked={enabled}
          aria-labelledby="email-pref-label"
          aria-describedby="email-pref-desc"
          disabled={pending}
          onClick={toggle}
          className={cn(
            "relative inline-flex h-7 w-12 shrink-0 items-center rounded-full border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-60",
            enabled ? "border-primary bg-primary" : "border-input bg-secondary"
          )}
        >
          <span
            aria-hidden="true"
            className={cn(
              "inline-block h-5 w-5 rounded-full bg-background shadow transition-transform",
              enabled ? "translate-x-6" : "translate-x-1"
            )}
          />
        </button>
      </div>
      {message ? (
        <p
          role={message.tone === "error" ? "alert" : "status"}
          className={cn("mt-3 text-xs font-medium", message.tone === "error" ? "text-destructive" : "text-foreground")}
        >
          {message.text}
        </p>
      ) : null}
    </div>
  );
}
