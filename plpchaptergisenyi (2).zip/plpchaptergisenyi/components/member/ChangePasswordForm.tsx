"use client";

import { useState, type FormEvent } from "react";
import { changePassword } from "@/app/(member)/member/actions";
import { PasswordInput } from "@/components/auth/PasswordInput";
import { AuthAlert, primaryButtonClass, Spinner } from "@/components/auth/ui";
import { describedBy, Field } from "@/components/public/FormField";
import { getPasswordChecks } from "@/lib/auth-validation";

export function ChangePasswordForm() {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);
  const [saving, setSaving] = useState(false);

  const checks = getPasswordChecks(next);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (saving) return;
    setNotice(null);

    const found: Record<string, string> = {};
    if (!current) found.current = "Enter your current password.";
    if (checks.some((check) => !check.passed)) found.next = "Your new password doesn't meet all the requirements.";
    if (next !== confirm) found.confirm = "The two passwords don't match.";
    setErrors(found);
    const first = (["current", "next", "confirm"] as const).find((key) => found[key]);
    if (first) {
      document.getElementById(`password-${first}`)?.focus();
      return;
    }

    setSaving(true);
    try {
      const result = await changePassword({ current, next });
      if (result.ok) {
        setCurrent("");
        setNext("");
        setConfirm("");
        setErrors({});
        setNotice({ tone: "success", text: result.message ?? "Your password was changed." });
      } else {
        setErrors(result.fieldErrors ?? {});
        setNotice({ tone: "error", text: result.error });
      }
    } catch {
      setNotice({ tone: "error", text: "We couldn't reach the server. Check your connection and try again." });
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} noValidate aria-busy={saving} className="space-y-5">
      {notice ? <AuthAlert variant={notice.tone === "error" ? "error" : "success"}>{notice.text}</AuthAlert> : null}

      <Field id="password-current" label="Current password" required error={errors.current}>
        <PasswordInput
          id="password-current"
          autoComplete="current-password"
          value={current}
          onChange={(e) => setCurrent(e.target.value)}
          aria-invalid={Boolean(errors.current)}
          aria-describedby={describedBy("password-current", errors.current)}
        />
      </Field>

      <Field id="password-next" label="New password" required error={errors.next}>
        <PasswordInput
          id="password-next"
          autoComplete="new-password"
          value={next}
          onChange={(e) => setNext(e.target.value)}
          aria-invalid={Boolean(errors.next)}
          aria-describedby={describedBy("password-next", errors.next)}
        />
      </Field>

      <ul className="space-y-1 text-xs" aria-label="Password requirements">
        {checks.map((check) => (
          <li key={check.id} className={check.passed ? "text-foreground" : "text-muted-foreground"}>
            <span aria-hidden="true" className={check.passed ? "text-success" : undefined}>
              {check.passed ? "✓" : "•"}
            </span>{" "}
            {check.label}
          </li>
        ))}
      </ul>

      <Field id="password-confirm" label="Confirm new password" required error={errors.confirm}>
        <PasswordInput
          id="password-confirm"
          autoComplete="new-password"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          aria-invalid={Boolean(errors.confirm)}
          aria-describedby={describedBy("password-confirm", errors.confirm)}
        />
      </Field>

      <button type="submit" disabled={saving} className={primaryButtonClass}>
        {saving ? (
          <>
            <Spinner />
            Updating…
          </>
        ) : (
          "Change password"
        )}
      </button>
      <p className="text-xs text-muted-foreground">
        Changing your password signs you out of your other devices.
      </p>
    </form>
  );
}
