const base =
  "inline-flex items-center justify-center gap-2 rounded-md text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-60";

const variants = {
  primary: "bg-primary text-primary-foreground shadow-sm hover:bg-primary/90",
  outline: "border border-input bg-background text-foreground hover:bg-accent hover:text-accent-foreground",
  ghost: "text-foreground hover:bg-secondary",
} as const;

const sizes = { md: "h-10 px-4", lg: "h-11 px-6" } as const;

export function buttonClass(
  variant: keyof typeof variants = "primary",
  size: keyof typeof sizes = "md"
): string {
  return `${base} ${variants[variant]} ${sizes[size]}`;
}

const fieldBase =
  "w-full rounded-md border border-input bg-background px-3 text-sm text-foreground shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-60 aria-[invalid=true]:border-destructive";

export const selectClass = `${fieldBase} h-11`;
export const textareaClass = `${fieldBase} min-h-[140px] py-2`;
export const cardClass = "rounded-xl border bg-card text-card-foreground shadow-sm";
