import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export type BadgeTone = "success" | "warning" | "danger" | "primary" | "muted";

const TONES: Record<BadgeTone, string> = {
  success: "border-success/40 bg-success/15 text-foreground",
  warning: "border-warning/50 bg-warning/15 text-foreground",
  danger: "border-destructive/40 bg-destructive/10 text-destructive",
  primary: "border-primary/30 bg-accent text-accent-foreground",
  muted: "border-border bg-secondary text-muted-foreground",
};

const DOTS: Record<BadgeTone, string> = {
  success: "bg-success",
  warning: "bg-warning",
  danger: "bg-destructive",
  primary: "bg-primary",
  muted: "bg-muted-foreground",
};

export function Badge({
  tone = "muted",
  children,
  className,
}: {
  tone?: BadgeTone;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold",
        TONES[tone],
        className
      )}
    >
      <span aria-hidden="true" className={cn("h-1.5 w-1.5 rounded-full", DOTS[tone])} />
      {children}
    </span>
  );
}
