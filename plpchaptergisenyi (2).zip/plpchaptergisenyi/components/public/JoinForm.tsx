"use client";

import Link from "next/link";
import { useEffect, useState, type FormEvent } from "react";
import { PasswordInput } from "@/components/auth/PasswordInput";
import { AuthAlert, inputClass, primaryButtonClass, secondaryButtonClass, Spinner } from "@/components/auth/ui";
import { describedBy, Field, Honeypot } from "@/components/public/FormField";
import { selectClass, textareaClass } from "@/components/ui/styles";
import { getPasswordChecks, isValidEmail, normalizeEmail, validatePassword } from "@/lib/auth-validation";
import { createClient } from "@/lib/supabase/client";

interface JoinFormProps {
  applicationsOpen: boolean;
  chapterName: string;
}

interface Values {
  full_name: string;
  email: string;
  password: string;
  confirm: string;
  phone: string;
  date_of_birth: string;
  gender: string;
  sector_or_cell: string;
  school_or_occupation: string;
  skills_or_interests: string;
  motivation: string;
  consent: boolean;
  website: string;
}

type Errors = Partial<Record<keyof Values, string>>;

const INITIAL: Values = {
  full_name: "",
  email: "",
  password: "",
  confirm: "",
  phone: "",
  date_of_birth: "",
  gender: "",
  sector_or_cell: "",
  school_or_occupation: "",
  skills_or_interests: "",
  motivation: "",
  consent: false,
  website: "",
};

const FIELD_ORDER: Array<keyof Values> = [
  "full_name",
  "email",
  "password",
  "confirm",
  "phone",
  "date_of_birth",
  "sector_or_cell",
  "motivation",
  "consent",
];

const PHONE_PATTERN = /^[+()\d][\d\s()+-]{6,19}$/;

function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

function validate(values: Values, needsAccount: boolean): Errors {
  const errors: Errors = {};

  if (values.full_name.trim().length < 2) errors.full_name = "Enter your full name.";
  if (needsAccount) {
    if (!isValidEmail(values.email)) errors.email = "Enter a valid email address.";
    const passwordError = validatePassword(values.password);
    if (passwordError) errors.password = passwordError;
    if (values.password !== values.confirm) errors.confirm = "The two passwords don't match.";
  }
  if (!PHONE_PATTERN.test(values.phone.trim())) {
    errors.phone = "Enter a valid phone number, for example +250 788 000 000.";
  }
  if (values.date_of_birth) {
    const date = new Date(values.date_of_birth);
    if (Number.isNaN(date.getTime()) || date > new Date() || date.getFullYear() < 1900) {
      errors.date_of_birth = "Enter a valid date of birth.";
    }
  }
  if (values.sector_or_cell.trim().length < 2) errors.sector_or_cell = "Tell us your sector or cell.";
  if (values.motivation.trim().length < 20) {
    errors.motivation = "Please write at least a couple of sentences (20 characters or more).";
  }
  if (!values.consent) errors.consent = "Please confirm that we may use your details to review your application.";

  return errors;
}

type SessionUser = { id: string; email: string };
type Outcome = { needsConfirmation: boolean; signedIn: boolean };

export function JoinForm({ applicationsOpen, chapterName }: JoinFormProps) {
  const [values, setValues] = useState<Values>(INITIAL);
  const [errors, setErrors] = useState<Errors>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [alreadyExists, setAlreadyExists] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [outcome, setOutcome] = useState<Outcome | null>(null);
  const [sessionUser, setSessionUser] = useState<SessionUser | null>(null);

  useEffect(() => {
    let active = true;
    try {
      void createClient()
        .auth.getSession()
        .then(({ data }) => {
          const user = data.session?.user;
          if (active && user?.email) setSessionUser({ id: user.id, email: user.email });
        })
        .catch(() => undefined);
    } catch {
      // Supabase not configured: the submit handler reports it.
    }
    return () => {
      active = false;
    };
  }, []);

  function update<K extends keyof Values>(key: K, value: Values[K]) {
    setValues((current) => ({ ...current, [key]: value }));
    setErrors((current) => (current[key] ? { ...current, [key]: undefined } : current));
  }

  async function signOut() {
    try {
      await createClient().auth.signOut();
    } catch {
      // Ignore; state is cleared below either way.
    }
    setSessionUser(null);
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting) return;

    setFormError(null);
    setAlreadyExists(false);

    // Bots fill the hidden field; pretend success and do nothing.
    if (values.website) {
      setOutcome({ needsConfirmation: false, signedIn: false });
      return;
    }

    const needsAccount = !sessionUser;
    const found = validate(values, needsAccount);
    setErrors(found);
    const firstInvalid = FIELD_ORDER.find((key) => found[key]);
    if (firstInvalid) {
      document.getElementById(`join-${firstInvalid}`)?.focus();
      return;
    }

    let supabase: ReturnType<typeof createClient>;
    try {
      supabase = createClient();
    } catch {
      setFormError("Applications are temporarily unavailable. Please try again later or contact the chapter.");
      return;
    }

    setSubmitting(true);
    const email = sessionUser ? normalizeEmail(sessionUser.email) : normalizeEmail(values.email);
    let userId = sessionUser?.id ?? null;
    let accountCreated = false;
    let needsConfirmation = false;

    try {
      if (!sessionUser) {
        const { data, error } = await supabase.auth.signUp({
          email,
          password: values.password,
          options: {
            data: { full_name: values.full_name.trim(), phone: values.phone.trim() },
            emailRedirectTo: `${window.location.origin}/login`,
          },
        });

        if (error) {
          if (error.code === "user_already_exists") {
            setAlreadyExists(true);
          } else if (error.code === "weak_password") {
            setErrors({ password: "That password is too easy to guess. Try a longer or less common one." });
          } else if (error.status === 429 || error.code === "over_email_send_rate_limit") {
            setFormError("Too many sign-ups right now. Please wait a few minutes and try again.");
          } else {
            setFormError("We couldn't create your account right now. Please try again.");
          }
          setSubmitting(false);
          return;
        }

        // Supabase hides existing accounts by returning a user with no identities.
        if (!data.user || (data.user.identities && data.user.identities.length === 0)) {
          setAlreadyExists(true);
          setSubmitting(false);
          return;
        }

        userId = data.user.id;
        accountCreated = true;
        needsConfirmation = !data.session;
      }

      const { error: insertError } = await supabase.from("membership_applications").insert({
        user_id: userId,
        full_name: values.full_name.trim(),
        email,
        phone: values.phone.trim(),
        date_of_birth: values.date_of_birth || null,
        gender: values.gender || null,
        sector_or_cell: values.sector_or_cell.trim(),
        school_or_occupation: values.school_or_occupation.trim() || null,
        motivation: values.motivation.trim(),
        skills_or_interests: values.skills_or_interests.trim() || null,
        status: "pending",
      });

      if (insertError) {
        setFormError(
          accountCreated
            ? "Your account was created, but we couldn't save your application. Confirm your email, sign in, then come back to this page and submit again."
            : "We couldn't submit your application right now. Please try again in a few minutes."
        );
        setSubmitting(false);
        return;
      }

      setOutcome({ needsConfirmation, signedIn: Boolean(sessionUser) });
      setSubmitting(false);
    } catch {
      setFormError("We couldn't reach the server. Check your connection and try again.");
      setSubmitting(false);
    }
  }

  if (!applicationsOpen) {
    return (
      <AuthAlert variant="warning" title="Applications are closed for now">
        {chapterName} is not accepting new applications at the moment. Please check back soon, or{" "}
        <Link href="/contact" className="font-semibold underline underline-offset-4">
          contact the chapter
        </Link>{" "}
        with any questions.
      </AuthAlert>
    );
  }

  if (outcome) {
    return (
      <div className="space-y-4" role="status">
        <AuthAlert variant="success" title="Application received">
          Thank you for applying to {chapterName}. Chapter leaders will review your application and you
          will be notified by email once a decision is made.
          {outcome.needsConfirmation
            ? " Please also check your inbox and confirm your email address so you can sign in."
            : ""}
        </AuthAlert>
        <Link href="/" className={secondaryButtonClass}>
          Back to the home page
        </Link>
      </div>
    );
  }

  const checks = getPasswordChecks(values.password);

  return (
    <form onSubmit={handleSubmit} noValidate aria-busy={submitting} className="relative space-y-6">
      <Honeypot value={values.website} onChange={(value) => update("website", value)} />

      {sessionUser ? (
        <AuthAlert variant="info">
          You are signed in as <span className="font-semibold">{sessionUser.email}</span>. Your application
          will be linked to this account.{" "}
          <button type="button" onClick={signOut} className="font-semibold underline underline-offset-4">
            Not you? Sign out
          </button>
        </AuthAlert>
      ) : null}

      {formError ? <AuthAlert variant="error">{formError}</AuthAlert> : null}
      {alreadyExists ? (
        <AuthAlert variant="warning" title="This email already has an account">
          <Link href="/login?next=%2Fjoin" className="font-semibold underline underline-offset-4">
            Sign in
          </Link>{" "}
          to apply with it, or{" "}
          <Link href="/forgot-password" className="font-semibold underline underline-offset-4">
            reset your password
          </Link>{" "}
          if you have forgotten it.
        </AuthAlert>
      ) : null}

      <fieldset className="space-y-4">
        <legend className="text-lg font-semibold tracking-tight">About you</legend>

        <Field id="join-full_name" label="Full name" required error={errors.full_name}>
          <input
            id="join-full_name"
            name="full_name"
            type="text"
            autoComplete="name"
            maxLength={120}
            value={values.full_name}
            onChange={(e) => update("full_name", e.target.value)}
            aria-invalid={Boolean(errors.full_name)}
            aria-describedby={describedBy("join-full_name", errors.full_name)}
            className={inputClass}
          />
        </Field>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field id="join-phone" label="Phone number" required error={errors.phone}>
            <input
              id="join-phone"
              name="phone"
              type="tel"
              inputMode="tel"
              autoComplete="tel"
              maxLength={20}
              value={values.phone}
              onChange={(e) => update("phone", e.target.value)}
              aria-invalid={Boolean(errors.phone)}
              aria-describedby={describedBy("join-phone", errors.phone)}
              className={inputClass}
              placeholder="+250 788 000 000"
            />
          </Field>
          <Field id="join-date_of_birth" label="Date of birth" error={errors.date_of_birth}>
            <input
              id="join-date_of_birth"
              name="date_of_birth"
              type="date"
              max={todayIso()}
              autoComplete="bday"
              value={values.date_of_birth}
              onChange={(e) => update("date_of_birth", e.target.value)}
              aria-invalid={Boolean(errors.date_of_birth)}
              aria-describedby={describedBy("join-date_of_birth", errors.date_of_birth)}
              className={inputClass}
            />
          </Field>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field id="join-gender" label="Gender">
            <select
              id="join-gender"
              name="gender"
              value={values.gender}
              onChange={(e) => update("gender", e.target.value)}
              className={selectClass}
            >
              <option value="">Select…</option>
              <option value="Female">Female</option>
              <option value="Male">Male</option>
              <option value="Prefer not to say">Prefer not to say</option>
            </select>
          </Field>
          <Field id="join-sector_or_cell" label="Sector or cell" required error={errors.sector_or_cell}>
            <input
              id="join-sector_or_cell"
              name="sector_or_cell"
              type="text"
              maxLength={120}
              value={values.sector_or_cell}
              onChange={(e) => update("sector_or_cell", e.target.value)}
              aria-invalid={Boolean(errors.sector_or_cell)}
              aria-describedby={describedBy("join-sector_or_cell", errors.sector_or_cell)}
              className={inputClass}
              placeholder="Where you live in Rubavu District"
            />
          </Field>
        </div>

        <Field id="join-school_or_occupation" label="School or occupation">
          <input
            id="join-school_or_occupation"
            name="school_or_occupation"
            type="text"
            maxLength={160}
            value={values.school_or_occupation}
            onChange={(e) => update("school_or_occupation", e.target.value)}
            className={inputClass}
          />
        </Field>
      </fieldset>

      <fieldset className="space-y-4">
        <legend className="text-lg font-semibold tracking-tight">Why you want to join</legend>

        <Field
          id="join-motivation"
          label="Your motivation"
          required
          hint="Tell us why you want to join and what you hope to contribute."
          error={errors.motivation}
        >
          <textarea
            id="join-motivation"
            name="motivation"
            maxLength={2000}
            value={values.motivation}
            onChange={(e) => update("motivation", e.target.value)}
            aria-invalid={Boolean(errors.motivation)}
            aria-describedby={describedBy("join-motivation", errors.motivation, "hint")}
            className={textareaClass}
          />
        </Field>

        <Field id="join-skills_or_interests" label="Skills or interests">
          <textarea
            id="join-skills_or_interests"
            name="skills_or_interests"
            maxLength={1000}
            value={values.skills_or_interests}
            onChange={(e) => update("skills_or_interests", e.target.value)}
            className={`${textareaClass} min-h-[96px]`}
          />
        </Field>
      </fieldset>

      {!sessionUser ? (
        <fieldset className="space-y-4">
          <legend className="text-lg font-semibold tracking-tight">Create your member account</legend>
          <p className="text-sm text-muted-foreground">
            You will use this email and password to sign in to the member portal once your application is
            approved.
          </p>

          <Field id="join-email" label="Email address" required error={errors.email}>
            <input
              id="join-email"
              name="email"
              type="email"
              inputMode="email"
              autoComplete="email"
              autoCapitalize="none"
              spellCheck={false}
              maxLength={254}
              value={values.email}
              onChange={(e) => update("email", e.target.value)}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={describedBy("join-email", errors.email)}
              className={inputClass}
            />
          </Field>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field id="join-password" label="Password" required error={errors.password}>
              <PasswordInput
                id="join-password"
                name="new-password"
                autoComplete="new-password"
                value={values.password}
                onChange={(e) => update("password", e.target.value)}
                aria-invalid={Boolean(errors.password)}
                aria-describedby={describedBy("join-password", errors.password)}
              />
            </Field>
            <Field id="join-confirm" label="Confirm password" required error={errors.confirm}>
              <PasswordInput
                id="join-confirm"
                name="confirm-password"
                autoComplete="new-password"
                value={values.confirm}
                onChange={(e) => update("confirm", e.target.value)}
                aria-invalid={Boolean(errors.confirm)}
                aria-describedby={describedBy("join-confirm", errors.confirm)}
              />
            </Field>
          </div>

          <ul className="space-y-1 text-xs" aria-label="Password requirements">
            {checks.map((check) => (
              <li key={check.id} className={check.passed ? "text-foreground" : "text-muted-foreground"}>
                <span aria-hidden="true" className={check.passed ? "text-success" : undefined}>
                  {check.passed ? "✓" : "•"}
                </span>{" "}
                {check.label}
              </li>
            ))}
          </ul>
        </fieldset>
      ) : null}

      <div>
        <label className="flex items-start gap-3 text-sm leading-6">
          <input
            id="join-consent"
            type="checkbox"
            checked={values.consent}
            onChange={(e) => update("consent", e.target.checked)}
            aria-invalid={Boolean(errors.consent)}
            aria-describedby={errors.consent ? "join-consent-error" : undefined}
            className="mt-1 h-4 w-4 rounded border-input accent-primary"
          />
          <span>
            I agree that {chapterName} may store and use these details to review my application and to
            contact me about my membership.
          </span>
        </label>
        {errors.consent ? (
          <p id="join-consent-error" role="alert" className="mt-1.5 text-xs font-medium text-destructive">
            {errors.consent}
          </p>
        ) : null}
      </div>

      <button type="submit" disabled={submitting} className={primaryButtonClass}>
        {submitting ? (
          <>
            <Spinner />
            Submitting…
          </>
        ) : (
          "Submit application"
        )}
      </button>

      <p className="text-center text-sm text-muted-foreground">
        Already a member?{" "}
        <Link href="/login" className="font-medium text-primary underline-offset-4 hover:underline">
          Sign in
        </Link>
      </p>
    </form>
  );
}
