import { cn, toParagraphs } from "@/lib/utils";

/** Renders plain CMS text as paragraphs. Never injects HTML, so stored content cannot run scripts. */
export function TextContent({ text, className }: { text: string; className?: string }) {
  return (
    <div className={cn("space-y-4 text-base leading-7", className)}>
      {toParagraphs(text).map((block, index) => (
        <p key={index} className="whitespace-pre-line">
          {block}
        </p>
      ))}
    </div>
  );
}
