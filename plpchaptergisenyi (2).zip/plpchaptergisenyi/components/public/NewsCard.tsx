import Link from "next/link";
import { CoverImage } from "@/components/public/CoverImage";
import type { NewsSummary } from "@/lib/public-data";
import { formatDate, truncate } from "@/lib/utils";

export function NewsCard({ article }: { article: NewsSummary }) {
  const published = article.published_at ?? article.created_at;

  return (
    <article className="relative flex h-full flex-col overflow-hidden rounded-xl border bg-card text-card-foreground shadow-sm transition-shadow hover:shadow-md focus-within:ring-2 focus-within:ring-ring">
      <CoverImage
        src={article.cover_image_url}
        alt={`Cover image for ${article.title}`}
        className="aspect-[16/9] w-full"
      />
      <div className="flex flex-1 flex-col p-5">
        <time dateTime={published} className="text-xs font-medium text-muted-foreground">
          {formatDate(published)}
        </time>
        <h3 className="mt-1 text-lg sm:text-lg">
          <Link
            href={`/news/${article.slug}`}
            className="after:absolute after:inset-0 focus-visible:outline-none"
          >
            {article.title}
          </Link>
        </h3>
        <p className="mt-2 text-sm leading-6 text-muted-foreground">{truncate(article.excerpt, 160)}</p>
      </div>
    </article>
  );
}
