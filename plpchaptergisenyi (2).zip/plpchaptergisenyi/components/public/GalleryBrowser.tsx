"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { YouTubeEmbed } from "@/components/public/YouTubeEmbed";
import { cn } from "@/lib/utils";

export interface GalleryItemView {
  id: string;
  title: string;
  caption: string | null;
  alt: string;
  type: "photo" | "video";
  url: string;
  videoId: string | null;
  eventTitle: string | null;
  eventSlug: string | null;
}

type Filter = "all" | "photo" | "video";

export function GalleryBrowser({ items }: { items: GalleryItemView[] }) {
  const [filter, setFilter] = useState<Filter>("all");
  const [active, setActive] = useState<GalleryItemView | null>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);

  const photoCount = useMemo(() => items.filter((item) => item.type === "photo").length, [items]);
  const videoCount = items.length - photoCount;
  const visible = useMemo(
    () => (filter === "all" ? items : items.filter((item) => item.type === filter)),
    [items, filter]
  );

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (active && !dialog.open) dialog.showModal();
    if (!active && dialog.open) dialog.close();
  }, [active]);

  const filters: Array<{ id: Filter; label: string; count: number }> = [
    { id: "all", label: "All", count: items.length },
    { id: "photo", label: "Photos", count: photoCount },
    { id: "video", label: "Videos", count: videoCount },
  ];

  return (
    <div>
      <div className="flex flex-wrap gap-2" role="group" aria-label="Filter gallery">
        {filters.map((option) => (
          <button
            key={option.id}
            type="button"
            onClick={() => setFilter(option.id)}
            aria-pressed={filter === option.id}
            className={cn(
              "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              filter === option.id
                ? "border-primary bg-primary text-primary-foreground"
                : "border-input bg-background text-foreground hover:bg-secondary"
            )}
          >
            {option.label} <span className="opacity-80">({option.count})</span>
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <p className="mt-8 rounded-xl border bg-card p-8 text-center text-sm text-muted-foreground">
          Nothing to show in this category yet.
        </p>
      ) : (
        <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {visible.map((item) => (
            <li key={item.id}>
              <figure className="overflow-hidden rounded-xl border bg-card shadow-sm">
                {item.type === "video" && item.videoId ? (
                  <YouTubeEmbed videoId={item.videoId} title={item.title} />
                ) : item.type === "video" ? (
                  <a
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex aspect-video items-center justify-center bg-secondary text-sm font-semibold text-primary underline-offset-4 hover:underline"
                  >
                    Watch video on the original site
                  </a>
                ) : (
                  <button
                    type="button"
                    onClick={() => setActive(item)}
                    aria-label={`Enlarge photo: ${item.title}`}
                    className="block w-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={item.url}
                      alt={item.alt}
                      loading="lazy"
                      decoding="async"
                      className="aspect-[4/3] w-full object-cover"
                    />
                  </button>
                )}
                <figcaption className="p-4">
                  <p className="font-semibold leading-snug">{item.title}</p>
                  {item.caption ? <p className="mt-1 text-sm text-muted-foreground">{item.caption}</p> : null}
                  {item.eventSlug && item.eventTitle ? (
                    <p className="mt-2 text-xs text-muted-foreground">
                      From{" "}
                      <Link
                        href={`/events/${item.eventSlug}`}
                        className="font-medium text-primary underline-offset-4 hover:underline"
                      >
                        {item.eventTitle}
                      </Link>
                    </p>
                  ) : null}
                </figcaption>
              </figure>
            </li>
          ))}
        </ul>
      )}

      <dialog
        ref={dialogRef}
        onClose={() => setActive(null)}
        onClick={(event) => {
          if (event.target === dialogRef.current) setActive(null);
        }}
        aria-label={active ? active.title : "Photo viewer"}
        className="m-auto max-h-[92vh] w-[min(96vw,1000px)] rounded-xl border bg-card p-0 text-card-foreground shadow-xl backdrop:bg-foreground/70"
      >
        {active ? (
          <div className="relative">
            <button
              type="button"
              onClick={() => setActive(null)}
              aria-label="Close photo"
              className="absolute right-3 top-3 inline-flex h-9 w-9 items-center justify-center rounded-full bg-background/90 text-foreground shadow focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
                <path d="M6 6l12 12M18 6L6 18" />
              </svg>
            </button>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={active.url} alt={active.alt} className="max-h-[76vh] w-full object-contain bg-secondary" />
            <div className="p-4">
              <p className="font-semibold">{active.title}</p>
              {active.caption ? <p className="mt-1 text-sm text-muted-foreground">{active.caption}</p> : null}
            </div>
          </div>
        ) : null}
      </dialog>
    </div>
  );
}
