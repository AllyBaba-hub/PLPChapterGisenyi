import Link from "next/link";
import { CoverImage } from "@/components/public/CoverImage";
import type { EventSummary } from "@/lib/public-data";
import { cn, formatEventWhen, getDateParts, truncate } from "@/lib/utils";

interface EventCardProps {
  event: EventSummary;
  past?: boolean;
}

export function EventCard({ event, past = false }: EventCardProps) {
  const parts = getDateParts(event.start_time);

  return (
    <article className="relative flex h-full flex-col overflow-hidden rounded-xl border bg-card text-card-foreground shadow-sm transition-shadow hover:shadow-md focus-within:ring-2 focus-within:ring-ring">
      <CoverImage
        src={event.cover_image_url}
        alt={`Cover image for ${event.title}`}
        className="aspect-[16/9] w-full"
      />
      <div className="flex flex-1 gap-4 p-5">
        <div
          aria-hidden="true"
          className={cn(
            "flex h-14 w-14 shrink-0 flex-col items-center justify-center rounded-lg text-center",
            past ? "bg-secondary text-muted-foreground" : "bg-accent text-accent-foreground"
          )}
        >
          <span className="text-lg font-bold leading-none">{parts.day}</span>
          <span className="mt-0.5 text-xs font-medium uppercase">{parts.month}</span>
        </div>
        <div className="min-w-0">
          <h3 className="text-lg sm:text-lg">
            <Link
              href={`/events/${event.slug}`}
              className="after:absolute after:inset-0 focus-visible:outline-none"
            >
              {event.title}
            </Link>
          </h3>
          <p className="mt-1 text-sm text-muted-foreground">{formatEventWhen(event.start_time, event.end_time)}</p>
          <p className="text-sm text-muted-foreground">{event.location}</p>
          <p className="mt-2 text-sm leading-6">{truncate(event.summary, 140)}</p>
        </div>
      </div>
    </article>
  );
}
