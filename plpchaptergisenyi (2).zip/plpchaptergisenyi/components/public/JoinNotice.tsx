"use client";

import { useSearchParams } from "next/navigation";
import { AuthAlert } from "@/components/auth/ui";

/** Reads ?notice=pending-approval (set by middleware) without making the whole page dynamic. */
export function JoinNotice() {
  const notice = useSearchParams().get("notice");
  if (notice !== "pending-approval") return null;

  return (
    <AuthAlert variant="info" title="Your account is waiting for approval">
      Member areas open once chapter leaders approve your application. If you haven&apos;t applied yet,
      submit the form below. If you already applied, there is nothing more to do; you will be emailed
      when a decision is made.
    </AuthAlert>
  );
}
