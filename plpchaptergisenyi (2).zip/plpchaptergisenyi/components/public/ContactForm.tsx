"use client";

import { useEffect, useState, type FormEvent } from "react";
import { AuthAlert, inputClass, primaryButtonClass, secondaryButtonClass, Spinner } from "@/components/auth/ui";
import { describedBy, Field, Honeypot } from "@/components/public/FormField";
import { textareaClass } from "@/components/ui/styles";
import { isValidEmail, normalizeEmail } from "@/lib/auth-validation";
import { createClient } from "@/lib/supabase/client";

interface Values {
  sender_name: string;
  sender_email: string;
  sender_phone: string;
  subject: string;
  message: string;
  website: string;
}

type Errors = Partial<Record<keyof Values, string>>;

const INITIAL: Values = {
  sender_name: "",
  sender_email: "",
  sender_phone: "",
  subject: "",
  message: "",
  website: "",
};

const PHONE_PATTERN = /^[+()\d][\d\s()+-]{6,19}$/;
const COOLDOWN_SECONDS = 30;

function validate(values: Values): Errors {
  const errors: Errors = {};
  if (values.sender_name.trim().length < 2) errors.sender_name = "Enter your name.";
  if (!isValidEmail(values.sender_email)) errors.sender_email = "Enter a valid email address.";
  if (values.sender_phone.trim() && !PHONE_PATTERN.test(values.sender_phone.trim())) {
    errors.sender_phone = "Enter a valid phone number or leave this blank.";
  }
  if (values.subject.trim().length < 3) errors.subject = "Add a short subject.";
  if (values.message.trim().length < 10) errors.message = "Please write at least a short message (10 characters or more).";
  return errors;
}

export function ContactForm() {
  const [values, setValues] = useState<Values>(INITIAL);
  const [errors, setErrors] = useState<Errors>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [sent, setSent] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = window.setTimeout(() => setCooldown((value) => value - 1), 1000);
    return () => window.clearTimeout(timer);
  }, [cooldown]);

  function update<K extends keyof Values>(key: K, value: Values[K]) {
    setValues((current) => ({ ...current, [key]: value }));
    setErrors((current) => (current[key] ? { ...current, [key]: undefined } : current));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting || cooldown > 0) return;
    setFormError(null);

    if (values.website) {
      setSent(true);
      return;
    }

    const found = validate(values);
    setErrors(found);
    const order: Array<keyof Values> = ["sender_name", "sender_email", "sender_phone", "subject", "message"];
    const firstInvalid = order.find((key) => found[key]);
    if (firstInvalid) {
      document.getElementById(`contact-${firstInvalid}`)?.focus();
      return;
    }

    let supabase: ReturnType<typeof createClient>;
    try {
      supabase = createClient();
    } catch {
      setFormError("The contact form is temporarily unavailable. Please email the chapter directly.");
      return;
    }

    setSubmitting(true);
    try {
      const { error } = await supabase.from("contact_messages").insert({
        sender_name: values.sender_name.trim(),
        sender_email: normalizeEmail(values.sender_email),
        sender_phone: values.sender_phone.trim() || null,
        subject: values.subject.trim(),
        message: values.message.trim(),
        status: "unread",
      });

      if (error) {
        setFormError("We couldn't send your message right now. Please try again in a few minutes.");
        setSubmitting(false);
        return;
      }

      setSent(true);
      setValues(INITIAL);
      setCooldown(COOLDOWN_SECONDS);
      setSubmitting(false);
    } catch {
      setFormError("We couldn't reach the server. Check your connection and try again.");
      setSubmitting(false);
    }
  }

  if (sent) {
    return (
      <div className="space-y-4" role="status">
        <AuthAlert variant="success" title="Message sent">
          Thank you for contacting us. Chapter leaders will read your message and reply by email.
        </AuthAlert>
        <button
          type="button"
          onClick={() => setSent(false)}
          disabled={cooldown > 0}
          className={secondaryButtonClass}
        >
          {cooldown > 0 ? `Send another message in ${cooldown}s` : "Send another message"}
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} noValidate aria-busy={submitting} className="relative space-y-4">
      <Honeypot value={values.website} onChange={(value) => update("website", value)} />
      {formError ? <AuthAlert variant="error">{formError}</AuthAlert> : null}

      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="contact-sender_name" label="Your name" required error={errors.sender_name}>
          <input
            id="contact-sender_name"
            name="name"
            type="text"
            autoComplete="name"
            maxLength={120}
            value={values.sender_name}
            onChange={(e) => update("sender_name", e.target.value)}
            aria-invalid={Boolean(errors.sender_name)}
            aria-describedby={describedBy("contact-sender_name", errors.sender_name)}
            className={inputClass}
          />
        </Field>
        <Field id="contact-sender_email" label="Email address" required error={errors.sender_email}>
          <input
            id="contact-sender_email"
            name="email"
            type="email"
            inputMode="email"
            autoComplete="email"
            autoCapitalize="none"
            spellCheck={false}
            maxLength={254}
            value={values.sender_email}
            onChange={(e) => update("sender_email", e.target.value)}
            aria-invalid={Boolean(errors.sender_email)}
            aria-describedby={describedBy("contact-sender_email", errors.sender_email)}
            className={inputClass}
          />
        </Field>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="contact-sender_phone" label="Phone number" error={errors.sender_phone}>
          <input
            id="contact-sender_phone"
            name="phone"
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            maxLength={20}
            value={values.sender_phone}
            onChange={(e) => update("sender_phone", e.target.value)}
            aria-invalid={Boolean(errors.sender_phone)}
            aria-describedby={describedBy("contact-sender_phone", errors.sender_phone)}
            className={inputClass}
          />
        </Field>
        <Field id="contact-subject" label="Subject" required error={errors.subject}>
          <input
            id="contact-subject"
            name="subject"
            type="text"
            maxLength={150}
            value={values.subject}
            onChange={(e) => update("subject", e.target.value)}
            aria-invalid={Boolean(errors.subject)}
            aria-describedby={describedBy("contact-subject", errors.subject)}
            className={inputClass}
          />
        </Field>
      </div>

      <Field id="contact-message" label="Message" required error={errors.message}>
        <textarea
          id="contact-message"
          name="message"
          maxLength={3000}
          value={values.message}
          onChange={(e) => update("message", e.target.value)}
          aria-invalid={Boolean(errors.message)}
          aria-describedby={describedBy("contact-message", errors.message)}
          className={textareaClass}
        />
      </Field>

      <button type="submit" disabled={submitting || cooldown > 0} className={primaryButtonClass}>
        {submitting ? (
          <>
            <Spinner />
            Sending…
          </>
        ) : (
          "Send message"
        )}
      </button>
    </form>
  );
}
