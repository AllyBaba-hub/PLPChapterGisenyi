import { BrandMark } from "@/components/layout/BrandLogo";
import { cn } from "@/lib/utils";

interface CoverImageProps {
  src: string | null;
  alt: string;
  className?: string;
  priority?: boolean;
}

/** Compressed Supabase Storage photo, or a branded placeholder when none is set. */
export function CoverImage({ src, alt, className, priority = false }: CoverImageProps) {
  if (!src) {
    return (
      <div
        aria-hidden="true"
        className={cn("flex items-center justify-center bg-accent/60", className)}
      >
        <BrandMark size={56} className="opacity-90" />
      </div>
    );
  }

  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={src}
      alt={alt}
      loading={priority ? "eager" : "lazy"}
      decoding="async"
      className={cn("object-cover", className)}
    />
  );
}
