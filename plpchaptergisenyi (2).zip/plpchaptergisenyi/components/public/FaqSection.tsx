import type { FaqItem } from "@/lib/content";

interface FaqSectionProps {
  faqs: FaqItem[];
  headingId: string;
  title?: string;
}

/** Visible Q&A block; the same content feeds the FAQPage JSON-LD so AI engines can cite it. */
export function FaqSection({ faqs, headingId, title = "Frequently asked questions" }: FaqSectionProps) {
  return (
    <section aria-labelledby={headingId} className="container py-12 sm:py-16">
      <h2 id={headingId}>{title}</h2>
      <dl className="mt-8 grid gap-6 md:grid-cols-2">
        {faqs.map((faq) => (
          <div key={faq.question} className="rounded-xl border bg-card p-6 shadow-sm">
            <dt className="text-lg font-semibold tracking-tight">{faq.question}</dt>
            <dd className="mt-2 text-sm leading-6 text-muted-foreground">{faq.answer}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}
