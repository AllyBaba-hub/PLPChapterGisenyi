import type { ReactNode } from "react";

interface PageIntroProps {
  title: string;
  description?: string;
  children?: ReactNode;
}

export function PageIntro({ title, description, children }: PageIntroProps) {
  return (
    <div className="border-b bg-secondary/50">
      <div className="container py-10 sm:py-14">
        {children}
        <h1>{title}</h1>
        {description ? (
          <p className="mt-3 max-w-2xl text-base leading-7 text-muted-foreground sm:text-lg">{description}</p>
        ) : null}
      </div>
    </div>
  );
}
