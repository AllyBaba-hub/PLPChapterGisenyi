-- ============================================================================
-- MIGRATION 7: 20260908120700_member_portal.sql
-- Member portal hardening: protected profile fields, capacity-safe event RSVP
-- ============================================================================

-- 1. Members may edit their own profile, but never identity/privilege columns.
--    (RLS already pins role and status; this also pins member_code, email, joined_at.)
CREATE OR REPLACE FUNCTION public.protect_profile_fields()
RETURNS TRIGGER AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND NOT public.is_admin() THEN
    NEW.member_code := OLD.member_code;
    NEW.email := OLD.email;
    NEW.joined_at := OLD.joined_at;
    NEW.role := OLD.role;
    NEW.status := OLD.status;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS trg_profiles_protect ON public.profiles;
CREATE TRIGGER trg_profiles_protect BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.protect_profile_fields();

-- 2. Registrations now go through register_for_event() so max_capacity cannot be
--    bypassed by inserting rows directly through the API.
DROP POLICY IF EXISTS "Active members can register themselves for events" ON public.event_registrations;

-- 3. Registration counts for published events (members cannot read other people's rows).
CREATE OR REPLACE FUNCTION public.event_registration_counts()
RETURNS TABLE (event_id UUID, registered_count BIGINT) AS $$
  SELECT r.event_id, COUNT(*)::BIGINT
  FROM public.event_registrations r
  JOIN public.events e ON e.id = r.event_id
  WHERE e.is_published = TRUE
    AND public.is_active_member()
  GROUP BY r.event_id;
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public;

-- 4. Atomic, capacity-checked registration. Returns a status string:
--    registered | already_registered | full | closed | not_found | forbidden
CREATE OR REPLACE FUNCTION public.register_for_event(p_event_id UUID)
RETURNS TEXT AS $$
DECLARE
  v_event public.events%ROWTYPE;
  v_count BIGINT;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_active_member() THEN
    RETURN 'forbidden';
  END IF;

  -- Lock the event row so simultaneous registrations are serialized.
  SELECT * INTO v_event
  FROM public.events
  WHERE id = p_event_id AND is_published = TRUE
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN 'not_found';
  END IF;

  IF COALESCE(v_event.end_time, v_event.start_time + INTERVAL '3 hours') < NOW() THEN
    RETURN 'closed';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.event_registrations
    WHERE event_id = p_event_id AND user_id = auth.uid()
  ) THEN
    RETURN 'already_registered';
  END IF;

  IF v_event.max_capacity IS NOT NULL THEN
    SELECT COUNT(*) INTO v_count FROM public.event_registrations WHERE event_id = p_event_id;
    IF v_count >= v_event.max_capacity THEN
      RETURN 'full';
    END IF;
  END IF;

  INSERT INTO public.event_registrations (event_id, user_id)
  VALUES (p_event_id, auth.uid())
  ON CONFLICT (event_id, user_id) DO NOTHING;

  RETURN 'registered';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- 5. Cancel own registration until the event starts.
--    Returns: cancelled | not_registered | closed | not_found | forbidden
CREATE OR REPLACE FUNCTION public.cancel_event_registration(p_event_id UUID)
RETURNS TEXT AS $$
DECLARE
  v_start TIMESTAMPTZ;
  v_deleted INT;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_active_member() THEN
    RETURN 'forbidden';
  END IF;

  SELECT start_time INTO v_start FROM public.events WHERE id = p_event_id;
  IF NOT FOUND THEN
    RETURN 'not_found';
  END IF;

  IF v_start < NOW() THEN
    RETURN 'closed';
  END IF;

  DELETE FROM public.event_registrations
  WHERE event_id = p_event_id AND user_id = auth.uid();
  GET DIAGNOSTICS v_deleted = ROW_COUNT;

  IF v_deleted = 0 THEN
    RETURN 'not_registered';
  END IF;
  RETURN 'cancelled';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- 6. Only signed-in users may call these functions.
REVOKE ALL ON FUNCTION public.event_registration_counts() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.register_for_event(UUID) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.cancel_event_registration(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.event_registration_counts() TO authenticated;
GRANT EXECUTE ON FUNCTION public.register_for_event(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.cancel_event_registration(UUID) TO authenticated;
