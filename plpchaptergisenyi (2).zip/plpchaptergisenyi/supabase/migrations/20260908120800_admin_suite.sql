-- ============================================================================
-- MIGRATION 8: 20260908120800_admin_suite.sql
-- Admin suite hardening: role hierarchy, protected participation history, indexes
-- ============================================================================

-- 1. Role hierarchy. Row-Level Security lets every admin update any profile, so
--    without this an ordinary admin could promote themselves to super_admin.
--    Rules (service-role / SQL-editor changes, where auth.uid() IS NULL, bypass them):
--      * nobody can change their own role or status
--      * only a super_admin can change an admin/super_admin account, or grant those roles
--      * the last active super_admin can never be demoted or suspended
--    Trigger name sorts before trg_profiles_protect, so it runs first.
CREATE OR REPLACE FUNCTION public.enforce_role_hierarchy()
RETURNS TRIGGER AS $$
DECLARE
  v_actor UUID := auth.uid();
BEGIN
  IF v_actor IS NULL THEN
    RETURN NEW;
  END IF;

  IF NEW.role IS NOT DISTINCT FROM OLD.role AND NEW.status IS NOT DISTINCT FROM OLD.status THEN
    RETURN NEW;
  END IF;

  -- Non-admin attempts are neutralised by protect_profile_fields().
  IF NOT public.is_admin() THEN
    RETURN NEW;
  END IF;

  IF OLD.id = v_actor THEN
    RAISE EXCEPTION 'You cannot change your own role or status';
  END IF;

  IF (OLD.role IN ('admin', 'super_admin') OR NEW.role IN ('admin', 'super_admin'))
     AND NOT public.is_super_admin() THEN
    RAISE EXCEPTION 'Only a super administrator can change administrator roles or accounts';
  END IF;

  IF OLD.role = 'super_admin' AND (NEW.role <> 'super_admin' OR NEW.status <> 'active') THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.profiles
      WHERE role = 'super_admin' AND status = 'active' AND id <> OLD.id
    ) THEN
      RAISE EXCEPTION 'At least one active super administrator is required';
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS trg_profiles_enforce_hierarchy ON public.profiles;
CREATE TRIGGER trg_profiles_enforce_hierarchy BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.enforce_role_hierarchy();

-- 2. Participation history stays intact: members can no longer delete their own
--    registration rows directly. They cancel through cancel_event_registration(),
--    which refuses once an event has started. Admins keep delete rights.
DROP POLICY IF EXISTS "Active members can unregister themselves; admins manage all" ON public.event_registrations;
DROP POLICY IF EXISTS "Admins can delete registrations" ON public.event_registrations;
CREATE POLICY "Admins can delete registrations"
  ON public.event_registrations FOR DELETE
  USING (public.is_admin());

-- 3. Indexes for admin filtering.
CREATE INDEX IF NOT EXISTS idx_contact_messages_status ON public.contact_messages(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON public.audit_logs(action, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_entity ON public.audit_logs(entity_type, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_registrations_event ON public.event_registrations(event_id);

-- 4. Bootstrap note: the first super administrator must be created from the SQL
--    editor, where auth.uid() is NULL and the rules above do not apply, e.g.:
--      UPDATE public.profiles
--      SET role = 'super_admin', status = 'active',
--          member_code = COALESCE(member_code, public.generate_member_code()),
--          joined_at = COALESCE(joined_at, NOW())
--      WHERE email = 'first.admin@example.org';
